<?php
include 'includes/header.php';

// 1. Tarif limitini tekshirish
$sub_stmt = $db->prepare("SELECT tp.* FROM user_subscriptions us 
                          JOIN tariff_plans tp ON us.tariff_id = tp.id 
                          WHERE us.user_id = ? AND us.payment_status = 'paid' 
                          AND us.end_date > NOW() LIMIT 1");
$sub_stmt->execute([$user_id]);
$my_plan = $sub_stmt->fetch(PDO::FETCH_ASSOC);

if (!$my_plan) {
    echo "<div class='alert alert-warning'>".Lang::t('no_active_subscription_access')."</div>";
    include 'includes/footer.php'; exit;
}

// 2. Mahsulotlar sonini tekshirish
$prod_count_stmt = $db->prepare("SELECT COUNT(*) FROM inventory WHERE user_id = ?");
$prod_count_stmt->execute([$user_id]);
$current_products = $prod_count_stmt->fetchColumn();

// 3. Toifa (Kategoriya) qo'shish jarayoni
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $stmt = $db->prepare("INSERT INTO inventory_categories (user_id, name) VALUES (?, ?)");
    $stmt->execute([$user_id, $_POST['cat_name']]);
    echo "<script>location.href='inventory.php?tab=cats&success=1';</script>";
}

// 4. Mahsulot qo'shish jarayoni
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    if ($current_products < $my_plan['product_limit']) {
        $ins = $db->prepare("INSERT INTO inventory (user_id, category_id, product_name, price, stock_quantity) VALUES (?, ?, ?, ?, ?)");
        $ins->execute([$user_id, $_POST['category_id'], $_POST['product_name'], $_POST['price'], $_POST['stock_quantity']]);
        echo "<script>location.href='inventory.php?success=2';</script>";
    } else {
        echo "<script>alert('".Lang::t('limit_reached')."');</script>";
    }
}

$tab = $_GET['tab'] ?? 'products';
?>

<div class="mb-4 bg-white p-3 rounded shadow-sm border-start border-primary border-5">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="fw-bold m-0"><?= Lang::t('inventory') ?></h4>
            <small class="text-muted"><?= Lang::t('products_limit') ?>: <b><?= $current_products ?> / <?= $my_plan['product_limit'] ?></b></small>
        </div>
        <div style="width: 200px;">
            <?php $percent = ($current_products / $my_plan['product_limit']) * 100; ?>
            <div class="progress" style="height: 10px;">
                <div class="progress-bar bg-primary" style="width: <?= $percent ?>%"></div>
            </div>
        </div>
    </div>
</div>

<ul class="nav nav-pills mb-4 bg-white p-2 rounded shadow-sm">
    <li class="nav-item">
        <a class="nav-link <?= $tab == 'products' ? 'active' : '' ?>" href="?tab=products"><i class="fas fa-box me-2"></i><?= Lang::t('products') ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $tab == 'cats' ? 'active' : '' ?>" href="?tab=cats"><i class="fas fa-tags me-2"></i><?= Lang::t('categories') ?></a>
    </li>
</ul>

<?php if ($tab == 'cats'): ?>
    <div class="card border-0 shadow-sm p-4 mb-4">
        <form class="row g-3" method="POST">
            <div class="col-md-4">
                <input type="text" name="cat_name" class="form-control" placeholder="<?= Lang::t('category_name') ?>" required>
            </div>
            <div class="col-auto">
                <button type="submit" name="add_category" class="btn btn-primary px-4"><?= Lang::t('add') ?></button>
            </div>
        </form>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <table class="table align-middle m-0">
            <thead class="table-light"><tr><th class="ps-4">ID</th><th><?= Lang::t('name') ?></th><th class="text-end pe-4"><?= Lang::t('action') ?></th></tr></thead>
            <tbody>
                <?php
                $cats_stmt = $db->prepare("SELECT * FROM inventory_categories WHERE user_id = ?");
                $cats_stmt->execute([$user_id]);
                $cats = $cats_stmt->fetchAll();
                foreach($cats as $c): ?>
                <tr><td class="ps-4">#<?= $c['id'] ?></td><td><?= htmlspecialchars($c['name']) ?></td><td class="text-end pe-4"><button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal" <?= ($current_products >= $my_plan['product_limit']) ? 'disabled' : '' ?>>
            <i class="fas fa-plus me-1"></i> <?= Lang::t('add_product') ?>
        </button>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <table class="table align-middle m-0 text-center">
            <thead class="table-light">
                <tr><th><?= Lang::t('name') ?></th><th><?= Lang::t('category') ?></th><th><?= Lang::t('price') ?></th><th><?= Lang::t('stock') ?></th><th><?= Lang::t('action') ?></th></tr>
            </thead>
            <tbody>
                <?php
                $prods = $db->prepare("SELECT i.*, ic.name as cat_name FROM inventory i LEFT JOIN inventory_categories ic ON i.category_id = ic.id WHERE i.user_id = ?");
                $prods->execute([$user_id]);
                foreach($prods->fetchAll() as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['product_name']) ?></td>
                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($p['cat_name'] ?? '---') ?></span></td>
                    <td class="fw-bold text-primary"><?= number_format($p['price'], 0) ?></td>
                    <td><span class="badge bg-<?= $p['stock_quantity'] > 5 ? 'success' : 'danger' ?>"><?= $p['stock_quantity'] ?></span></td>
                    <td><button class="btn btn-sm btn-light"><i class="fas fa-edit"></i></button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<div class="modal fade" id="addProductModal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" method="POST">
            <div class="modal-header border-0 pb-0"><h5 class="fw-bold"><?= Lang::t('new_product') ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="mb-3"><label class="small fw-bold"><?= Lang::t('category') ?></label>
                    <select name="category_id" class="form-select" required>
                        <?php foreach($cats as $c): ?><option value="<?= $c['id'] ?>"><?= $c['name'] ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3"><label class="small fw-bold"><?= Lang::t('name') ?></label><input type="text" name="product_name" class="form-control" required></div>
                <div class="row">
                    <div class="col-6 mb-3"><label class="small fw-bold"><?= Lang::t('price') ?></label><input type="number" name="price" class="form-control" required></div>
                    <div class="col-6 mb-3"><label class="small fw-bold"><?= Lang::t('stock') ?></label><input type="number" name="stock_quantity" class="form-control" required></div>
                </div>
            </div>
            <div class="modal-footer border-0"><button type="submit" name="add_product" class="btn btn-primary w-100"><?= Lang::t('save') ?></button></div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>