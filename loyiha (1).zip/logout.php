<?php
require_once 'core/Database.php';
require_once 'core/Auth.php';
$db = (new Database())->getConnection();
$auth = new Auth($db);
$auth->logout();
?>