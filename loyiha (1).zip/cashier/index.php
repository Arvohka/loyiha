<?php
require_once '../core/Database.php';
require_once '../core/Lang.php';
require_once '../core/Auth.php';

Auth::check();
if ($_SESSION['role'] !== 'cashier') { header("Location: login.php"); exit; }

$db = (new Database())->getConnection();
$cashier_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Kassir Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Windows/Program style menu */
        .app-menu { background: #f8f9fa; border-bottom: 1px solid #dee2e6; padding: 0 15px; }
        .app-menu .nav-link { color: #333; font-size: 14px; padding: 8px 15px !important; border-radius: 4px; }
        .app-menu .nav-link:hover { background: #e9ecef; color: #000; }
        .app-menu .active { background: #28a745 !important; color: #fff !important; }
        .status-bar { position: fixed; bottom: 0; width: 100%; background: #28a745; color: white; font-size: 12px; padding: 3px 15px; }
    </style>
</head>
<body class="bg-light">

<div class="app-menu shadow-sm d-flex align-items-center justify-content-between">
    <ul class="nav">
        <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fas fa-home me-1"></i> Asosiy</a></li>
        <li class="nav-item"><a class="nav-link" href="pos.php"><i class="fas fa-shopping-cart me-1"></i> Savdo (F2)</a></li>
        <li class="nav-item"><a class="nav-link" href="orders.php"><i class="fas fa-history me-1"></i> Savdolar tarixi</a></li>
        <li class="nav-item"><a class="nav-link" href="debts.php"><i class="fas fa-user-clock me-1"></i> Qarzlar</a></li>
    </ul>
    <div class="small fw-bold text-dark">
        <i class="fas fa-user me-1"></i> <?= $_SESSION['fullname'] ?> | 
        <a href="logout.php" class="text-danger text-decoration-none ms-2"><i class="fas fa-power-off"></i> Chiqish</a>
    </div>
</div>

<div class="container mt-5">
    <div class="row text-center">
        <div class="col-md-12 mb-4">
            <h2 class="fw-bold text-secondary">Xush kelibsiz, <?= $_SESSION['fullname'] ?>!</h2>
            <p class="text-muted">Ishni boshlash uchun quyidagi tugmani bosing yoki menyudan foydalaning.</p>
        </div>
        <div class="col-md-4 mx-auto">
            <a href="pos.php" class="card p-5 text-decoration-none shadow-sm border-0 bg-success text-white rounded-4">
                <i class="fas fa-cart-plus fa-4x mb-3"></i>
                <h4 class="fw-bold">YANGI SAVDO</h4>
            </a>
        </div>
    </div>
</div>

<div class="status-bar d-flex justify-content-between">
    <span>Tizim: Aktiv</span>
    <span>Sana: <?= date('d.m.Y') ?></span>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>