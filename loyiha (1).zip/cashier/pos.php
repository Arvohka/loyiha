<?php include 'includes/header.php'; ?>

<div class="container-fluid pos-wrapper mt-2">
    <div class="row h-100">
        <div class="col-md-8 h-100 d-flex flex-column">
            <div class="card border-0 shadow-sm p-3 mb-2">
                <div class="input-group shadow-sm">
                    <span class="input-group-text bg-white border-end-0 text-success"><i class="fas fa-barcode"></i></span>
                    <input type="text" id="search" class="form-control border-start-0 py-2" placeholder="Mahsulot nomi yoki shtrix-kod... (F2)" autofocus autocomplete="off">
                </div>
            </div>
            <div class="card border-0 shadow-sm p-3 flex-grow-1 overflow-auto bg-white" style="min-height: 400px;">
                <div class="row g-3" id="product-list">
                    <div class="text-center text-muted mt-5">
                        <i class="fas fa-search fa-3x mb-3 d-block opacity-25"></i>
                        Qidiruv natijalari shu yerda chiqadi...
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 h-100 d-flex flex-column">
            <div class="card border-0 shadow-sm p-3 flex-grow-1 d-flex flex-column bg-white">
                <h5 class="fw-bold mb-3 border-bottom pb-2">
                    <i class="fas fa-shopping-basket me-2 text-success"></i> Savatcha 
                    <span class="badge bg-success float-end rounded-pill" id="cart-count">0</span>
                </h5>
                <div class="table-responsive flex-grow-1">
                    <table class="table table-sm align-middle border-0">
                        <thead class="table-light">
                            <tr>
                                <th class="py-2">Nomi</th>
                                <th width="70">Soni</th>
                                <th class="text-end">Narxi</th>
                                <th class="text-end">#</th>
                            </tr>
                        </thead>
                        <tbody id="cart-items"></tbody>
                    </table>
                </div>
                
                <div class="bg-light p-3 rounded-4 mt-auto border shadow-sm">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="fw-bold text-secondary">Jami:</span>
                        <h3 class="fw-bold text-success mb-0" id="total-price">0 UZS</h3>
                    </div>
                    <button class="btn btn-success btn-lg w-100 fw-bold py-3 shadow" id="checkout-btn">
                        <i class="fas fa-money-bill-wave me-2"></i> TO'LOV (F9)
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="payModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title fw-bold">Sotuvni yakunlash</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="small fw-bold text-muted">TO'LOV TURI</label>
                    <select class="form-select form-select-lg fw-bold text-success" id="pay_type">
                        <option value="cash">NAQD</option>
                        <option value="card">PLASTIK KARTA</option>
                        <option value="debt">QARZGA SOTISH</option>
                    </select>
                </div>

                <div id="debt_fields" style="display: none;" class="p-3 bg-warning bg-opacity-10 rounded-3 mb-3 border border-warning">
                    <div class="mb-2">
                        <label class="small fw-bold text-dark">MIJOZ ISMI *</label>
                        <input type="text" id="customer_name" class="form-control" placeholder="F.I.SH">
                    </div>
                    <div>
                        <label class="small fw-bold text-dark">TELEFON RAQAMI</label>
                        <input type="text" id="customer_phone" class="form-control" placeholder="+998901234567">
                    </div>
                </div>

                <div class="mb-3" id="paid_amount_container">
                    <label class="small fw-bold text-muted">MIJOZ TO'LADI</label>
                    <input type="number" id="paid_amount" class="form-control form-control-lg fw-bold" placeholder="0">
                </div>
                <div class="p-3 bg-light rounded-3 text-center" id="change_container">
                    <span class="small text-muted d-block">QAYTIM</span>
                    <h4 class="fw-bold mb-0 text-danger" id="change_amount">0 UZS</h4>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-success btn-lg w-100 fw-bold" id="confirm-sale">TASDIQLASH</button>
            </div>
        </div>
    </div>
</div>

<div class="status-bar d-flex justify-content-between">
    <span>Tizim: Aktiv | Kassir: <?= $_SESSION['fullname'] ?></span>
    <span>Sana: <?= date('d.m.Y') ?></span>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
let cart = [];

$(document).ready(function() {
    // To'lov turi o'zgarganda qarz maydonlarini chiqarish
    $('#pay_type').on('change', function() {
        if ($(this).val() === 'debt') {
            $('#debt_fields').slideDown();
            $('#paid_amount_container, #change_container').hide();
            $('#paid_amount').val(0);
        } else {
            $('#debt_fields').slideUp();
            $('#paid_amount_container, #change_container').show();
        }
    });

    $('#search').on('input', function() {
        let val = $(this).val();
        if(val.length >= 2) {
            $.get('api_products.php', { query: val }, function(res) {
                $('#product-list').html(res);
            });
        }
    });

    $(document).on('click', '.product-item', function() {
        let id = $(this).data('id');
        let name = $(this).data('name');
        let price = parseFloat($(this).data('price'));

        let item = cart.find(i => i.id === id);
        if (item) { item.qty++; } else { cart.push({ id, name, price, qty: 1 }); }
        renderCart();
        $('#search').val('').focus();
    });

    $('#checkout-btn').click(function() {
        if(cart.length === 0) { alert('Savatcha bo\'sh!'); return; }
        $('#payModal').modal('show');
    });

    $('#paid_amount').on('input', function() {
        let total = calculateTotal();
        let paid = parseFloat($(this).val()) || 0;
        let change = paid - total;
        $('#change_amount').text(change > 0 ? change.toLocaleString() + ' UZS' : '0 UZS');
    });

    $('#confirm-sale').click(function() {
        if(cart.length === 0) return;

        let payType = $('#pay_type').val();
        let custName = $('#customer_name').val();
        let custPhone = $('#customer_phone').val();

        if (payType === 'debt' && custName.trim() === "") {
            alert("Iltimos, mijoz ismini kiriting!");
            return;
        }

        let saleData = {
            pay_type: payType,
            paid_amount: $('#paid_amount').val(),
            customer_name: custName,
            customer_phone: custPhone,
            items: cart
        };

        $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> SAQLANMOQDA...');

        $.ajax({
            url: 'complete_sale.php',
            method: 'POST',
            data: saleData,
            success: function(response) {
                try {
                    let res = JSON.parse(response);
                    if(res.status === 'success') {
                        window.open('print_receipt.php?id=' + res.sale_id, '_blank', 'width=300,height=600');
                        cart = [];
                        renderCart();
                        $('#payModal').modal('hide');
                        $('#paid_amount').val('');
                        $('#customer_name').val('');
                        $('#customer_phone').val('');
                        $('#search').val('').focus();
                    } else { alert('Xato: ' + res.message); }
                } catch(e) { alert('Tizim xatosi!'); }
            },
            error: function() { alert('Server bilan aloqa uzildi!'); },
            complete: function() { $('#confirm-sale').prop('disabled', false).text('TASDIQLASH'); }
        });
    });
});

function calculateTotal() { return cart.reduce((sum, item) => sum + (item.price * item.qty), 0); }

function renderCart() {
    let html = '';
    let total = calculateTotal();
    cart.forEach((item, index) => {
        let subtotal = item.price * item.qty;
        html += `<tr>
            <td class="small fw-bold text-truncate" style="max-width: 140px;">${item.name}</td>
            <td><input type="number" class="qty-input" value="${item.qty}" onchange="updateQty(${index}, this.value)" style="width:50px; text-align:center; border:1px solid #ddd; border-radius:4px;"></td>
            <td class="text-end small fw-bold">${subtotal.toLocaleString()}</td>
            <td class="text-end"><button class="btn btn-sm text-danger p-0" onclick="removeItem(${index})"><i class="fas fa-times-circle"></i></button></td>
        </tr>`;
    });
    $('#cart-items').html(html);
    $('#total-price').text(total.toLocaleString() + ' UZS');
    $('#cart-count').text(cart.length);
}

function updateQty(index, val) {
    if(val < 1) val = 1;
    cart[index].qty = parseInt(val);
    renderCart();
}

function removeItem(index) {
    cart.splice(index, 1);
    renderCart();
}

$(window).keydown(function(e) {
    if (e.keyCode === 120) $('#checkout-btn').click(); // F9
    if (e.keyCode === 113) $('#search').focus();       // F2
});
</script>
</body>
</html>