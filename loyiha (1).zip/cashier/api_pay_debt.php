<?php
session_start();
require_once '../core/Database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_POST['debt_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Ruxsat berilmagan']);
    exit;
}

$db = (new Database())->getConnection();
$debt_id = $_POST['debt_id'];
$pay_amount = floatval($_POST['pay_amount']);
$owner_id = $_SESSION['owner_id'];

if ($pay_amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'To\'lov summasi noto\'g\'ri']);
    exit;
}

try {
    $db->beginTransaction();

    // 1. Qarzni tekshirish
    $stmt = $db->prepare("SELECT amount, customer_name FROM debts WHERE id = ? AND owner_id = ?");
    $stmt->execute([$debt_id, $owner_id]);
    $debt = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$debt) {
        throw new Exception("Qarz ma'lumoti topilmadi");
    }

    if ($pay_amount > $debt['amount']) {
        throw new Exception("To'lov summasi qarzdan ko'p bo'lishi mumkin emas");
    }

    // 2. Qarz summasini kamaytirish
    $upd = $db->prepare("UPDATE debts SET amount = amount - ?, updated_at = NOW() WHERE id = ?");
    $upd->execute([$pay_amount, $debt_id]);

    // 3. To'lovlar tarixiga (sales) yozish (ixtiyoriy, hisobot uchun)
    $ins = $db->prepare("INSERT INTO sales (owner_id, cashier_id, total_amount, pay_type, customer_name, created_at) VALUES (?, ?, ?, 'cash', ?, NOW())");
    $ins->execute([$owner_id, $_SESSION['user_id'], $pay_amount, $debt['customer_name'] . " (Qarz to'lovi)"]);

    $db->commit();
    echo json_encode(['status' => 'success']);

} catch (Exception $e) {
    $db->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}