<?php 
include 'includes/header.php'; 

$cashier_id = $_SESSION['user_id'] ?? 0;
$owner_id = $_SESSION['owner_id'] ?? 0;

// Statistikani xatolarsiz olish
$stats = ['daily'=>0, 'weekly'=>0, 'monthly'=>0, 'yearly'=>0];
try {
    $st_stats = $db->prepare("SELECT 
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN total_amount ELSE 0 END) as daily,
        SUM(CASE WHEN YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1) THEN total_amount ELSE 0 END) as weekly,
        SUM(CASE WHEN MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) THEN total_amount ELSE 0 END) as monthly,
        SUM(CASE WHEN YEAR(created_at) = YEAR(CURDATE()) THEN total_amount ELSE 0 END) as yearly
        FROM sales WHERE cashier_id = ?");
    $st_stats->execute([$cashier_id]);
    $res = $st_stats->fetch(PDO::FETCH_ASSOC);
    if($res) $stats = $res;
} catch (Exception $e) {}
?>

<div class="container-fluid mt-4 px-4">
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 text-white" style="background: #007bff; border-radius: 10px;">
                <small class="fw-bold opacity-75">BUGUN</small>
                <h3 class="fw-bold mb-0"><?= number_format($stats['daily'] ?? 0) ?> UZS</h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 text-white" style="background: #28a745; border-radius: 10px;">
                <small class="fw-bold opacity-75">SHU HAFTA</small>
                <h3 class="fw-bold mb-0"><?= number_format($stats['weekly'] ?? 0) ?> UZS</h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 text-dark" style="background: #ffc107; border-radius: 10px;">
                <small class="fw-bold opacity-75">SHU OY</small>
                <h3 class="fw-bold mb-0"><?= number_format($stats['monthly'] ?? 0) ?> UZS</h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-3 text-white" style="background: #212529; border-radius: 10px;">
                <small class="fw-bold opacity-75">SHU YIL</small>
                <h3 class="fw-bold mb-0"><?= number_format($stats['yearly'] ?? 0) ?> UZS</h3>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm" style="border-radius: 10px;">
                <div class="card-header bg-white py-3 border-0">
                    <h6 class="fw-bold mb-0 text-danger"><i class="fas fa-book me-2"></i> Qora daftar (Hisobot)</h6>
                </div>
                <div class="card-body p-0">
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr><th class="ps-3 py-2 small">Mahsulot</th><th class="text-center small">Qoldiq</th></tr>
                        </thead>
                        <tbody>
                            <?php
                            try {
                                $st_low = $db->prepare("SELECT name, stock FROM products WHERE owner_id = ? AND stock <= 5 ORDER BY stock ASC LIMIT 10");
                                $st_low->execute([$owner_id]);
                                while($lp = $st_low->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td class="ps-3 small fw-bold text-truncate" style="max-width: 150px;"><?= htmlspecialchars($lp['name']) ?></td>
                                        <td class="text-center py-2"><span class="badge bg-danger"><?= $lp['stock'] ?> ta</span></td>
                                    </tr>
                                <?php endwhile;
                            } catch (Exception $e) { echo "<tr><td colspan='2' class='text-center p-2 small'>Xatolik yuz berdi</td></tr>"; }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card border-0 shadow-sm" style="border-radius: 10px;">
                <div class="card-header bg-white py-3 border-0">
                    <h6 class="fw-bold mb-0 text-success"><i class="fas fa-history me-2"></i> Savdolar tarixi</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3 py-2 small">ID</th>
                                    <th class="small">Vaqt</th>
                                    <th class="small">Summa</th>
                                    <th class="small">To'lov</th>
                                    <th class="text-end pe-3 small">Amal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                try {
                                    $stmt = $db->prepare("SELECT * FROM sales WHERE cashier_id = ? ORDER BY created_at DESC LIMIT 20");
                                    $stmt->execute([$cashier_id]);
                                    $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    if($sales):
                                        foreach($sales as $sale): ?>
                                        <tr>
                                            <td class="ps-3 fw-bold small">#<?= $sale['id'] ?></td>
                                            <td class="small text-muted"><?= date('H:i', strtotime($sale['created_at'])) ?></td>
                                            <td class="fw-bold text-success small"><?= number_format($sale['total_amount']) ?></td>
                                            <td><span class="badge bg-light text-dark border small"><?= strtoupper($sale['pay_type']) ?></span></td>
                                            <td class="text-end pe-3">
                                                <button onclick="printReceipt(<?= $sale['id'] ?>)" class="btn btn-sm btn-light border px-2 py-1"><i class="fas fa-print fa-sm"></i></button>
                                                <button onclick="viewDetails(<?= $sale['id'] ?>)" class="btn btn-sm btn-success px-2 py-1"><i class="fas fa-eye fa-sm"></i></button>
                                            </td>
                                        </tr>
                                        <?php endforeach; 
                                    else: echo "<tr><td colspan='5' class='text-center py-4 text-muted small'>Savdolar topilmadi</td></tr>";
                                    endif;
                                } catch (Exception $e) { echo "<tr><td colspan='5' class='text-center py-4 text-danger small'>Baza bilan bog'lanishda xatolik</td></tr>"; }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-success text-white py-2"><h6 class="modal-title fw-bold small">SAVDO TAFSILOTLARI</h6><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-0" id="details-content"></div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function printReceipt(id) { window.open('print_receipt.php?id=' + id, '_blank', 'width=300,height=600'); }
function viewDetails(id) {
    $('#detailsModal').modal('show');
    $('#details-content').html('<div class="p-4 text-center"><i class="fas fa-spinner fa-spin"></i></div>');
    $.get('api_sale_details.php', {id: id}, function(res) { $('#details-content').html(res); });
}
</script>
</body>
</html>