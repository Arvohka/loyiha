<?php
session_start();
require_once '../core/Database.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['items'])) {
    die(json_encode(['status' => 'error', 'message' => 'Ruxsat berilmagan']));
}

$db = (new Database())->getConnection();
$owner_id = $_SESSION['owner_id'];
$cashier_id = $_SESSION['user_id'];
$items = $_POST['items'];
$pay_type = $_POST['pay_type'];
$customer_name = $_POST['customer_name'] ?? null;
$customer_phone = $_POST['customer_phone'] ?? null;
$total_price = 0;

foreach($items as $i) { $total_price += ($i['price'] * $i['qty']); }

try {
    $db->beginTransaction();

    // 1. Umumiy savdoni yaratish (Mijoz ismi bilan)
    $stmt = $db->prepare("INSERT INTO sales (owner_id, cashier_id, total_amount, pay_type, customer_name, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$owner_id, $cashier_id, $total_price, $pay_type, $customer_name]);
    $sale_id = $db->lastInsertId();

    // 2. Har bir mahsulotni yozish va bazadagi sonini kamaytirish
    foreach ($items as $item) {
        $st_item = $db->prepare("INSERT INTO sales_items (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        $st_item->execute([$sale_id, $item['id'], $item['qty'], $item['price']]);

        $st_upd = $db->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
        $st_upd->execute([$item['qty'], $item['id']]);
    }

    // 3. Qarz bo'lsa, debts jadvalini yangilash
    if ($pay_type === 'debt' && !empty($customer_name)) {
        $st_check = $db->prepare("SELECT id FROM debts WHERE customer_name = ? AND owner_id = ?");
        $st_check->execute([$customer_name, $owner_id]);
        $debt_row = $st_check->fetch(PDO::FETCH_ASSOC);

        if ($debt_row) {
            $st_debt_up = $db->prepare("UPDATE debts SET amount = amount + ?, customer_phone = ?, updated_at = NOW() WHERE id = ?");
            $st_debt_up->execute([$total_price, $customer_phone, $debt_row['id']]);
        } else {
            $st_debt_in = $db->prepare("INSERT INTO debts (owner_id, customer_name, customer_phone, amount, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())");
            $st_debt_in->execute([$owner_id, $customer_name, $customer_phone, $total_price]);
        }
    }

    $db->commit();
    echo json_encode(['status' => 'success', 'sale_id' => $sale_id]);

} catch (Exception $e) {
    $db->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}