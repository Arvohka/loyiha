<?php
session_start();
require_once '../core/Database.php';
require_once '../core/Lang.php';

$db = (new Database())->getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // 1. staff jadvalidan login va holatni tekshirish
    $stmt = $db->prepare("SELECT * FROM staff WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. Parolni tekshirish (staff jadvalidagi password_hash bilan)
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['owner_id'] = $user['owner_id']; // Xo'jayin (Owner) ID-si
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['role'] = $user['role']; // cashier yoki warehouseman
        
        header("Location: index.php");
        exit;
    } else {
        $error = "Login yoki parol xato!";
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kassa - Kirish</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f7f6; height: 100vh; display: flex; align-items: center; justify-content: center; font-family: sans-serif; }
        .login-card { width: 400px; border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        .btn-success { background-color: #28a745; border: none; padding: 12px; border-radius: 10px; font-weight: 600; }
        .form-control { padding: 12px; border-radius: 10px; border: 1px solid #eee; }
    </style>
</head>
<body>

<div class="card login-card p-4">
    <div class="text-center mb-4">
        <h2 class="fw-bold text-success">KASSA TIZIMI</h2>
        <p class="text-muted small">Ishchi paneli orqali tizimga kiring</p>
    </div>

    <?php if($error): ?>
        <div class="alert alert-danger py-2 small text-center"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label small fw-bold">Login</label>
            <input type="text" name="username" class="form-control" placeholder="Loginni kiriting" required>
        </div>
        <div class="mb-4">
            <label class="form-label small fw-bold">Parol</label>
            <input type="password" name="password" class="form-control" placeholder="********" required>
        </div>
        <button type="submit" class="btn btn-success w-100">Kirish</button>
    </form>
</div>

</body>
</html>