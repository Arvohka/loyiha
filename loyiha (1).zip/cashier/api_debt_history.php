<?php
session_start();
require_once '../core/Database.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['customer_name'])) {
    die("<div class='p-3 text-danger'>Ruxsat berilmagan.</div>");
}

$db = (new Database())->getConnection();
$owner_id = $_SESSION['owner_id'];
$customer_name = $_GET['customer_name'];

try {
    // Mijozning barcha qarzga olingan savdolarini va mahsulotlarini olish
    $query = "SELECT s.id as sale_id, s.created_at, si.quantity, si.price, p.name as product_name 
              FROM sales s 
              JOIN sales_items si ON s.id = si.sale_id 
              JOIN products p ON si.product_id = p.id 
              WHERE s.customer_name = ? AND s.pay_type = 'debt' AND s.owner_id = ? 
              ORDER BY s.created_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$customer_name, $owner_id]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$history) {
        die("<div class='p-4 text-center text-muted'>Ushbu mijoz uchun savdo tarixi topilmadi.</div>");
    }
    ?>
    <div class="table-responsive">
        <table class="table table-sm table-striped mb-0">
            <thead class="table-dark">
                <tr>
                    <th class="ps-3 py-2 small">Sana</th>
                    <th class="small">Mahsulot</th>
                    <th class="text-center small">Soni</th>
                    <th class="text-end pe-3 small">Summa</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $grand_total = 0;
                foreach ($history as $row): 
                    $subtotal = $row['quantity'] * $row['price'];
                    $grand_total += $subtotal;
                ?>
                <tr>
                    <td class="ps-3 small"><?= date('d.m.Y H:i', strtotime($row['created_at'])) ?></td>
                    <td class="small fw-bold"><?= htmlspecialchars($row['product_name']) ?></td>
                    <td class="text-center small"><?= $row['quantity'] ?></td>
                    <td class="text-end pe-3 small fw-bold"><?= number_format($subtotal) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot class="table-light">
                <tr>
                    <th colspan="3" class="text-end">Jami qarzga olingan:</th>
                    <th class="text-end pe-3 text-danger"><?= number_format($grand_total) ?> UZS</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php
} catch (Exception $e) {
    echo "<div class='p-3 text-danger'>Xatolik: " . $e->getMessage() . "</div>";
}