<?php
session_start();
require_once '../core/Database.php';

$db = (new Database())->getConnection();
$owner_id = $_SESSION['owner_id'];
$query = isset($_GET['query']) ? trim($_GET['query']) : '';

if ($query !== '') {
    $stmt = $db->prepare("SELECT * FROM products WHERE owner_id = ? AND (name LIKE ? OR barcode = ?) LIMIT 24");
    $stmt->execute([$owner_id, "%$query%", $query]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($products) {
        foreach ($products as $p) {
            echo '
            <div class="col-6 col-md-4 col-lg-3">
                <div class="card h-100 border-0 shadow-sm product-item text-center p-2" 
                     style="cursor:pointer;" 
                     data-id="'.$p['id'].'" 
                     data-name="'.$p['name'].'" 
                     data-price="'.$p['price'].'">
                    <div class="card-body p-1">
                        <div class="fw-bold small text-truncate" title="'.$p['name'].'">'.$p['name'].'</div>
                        <div class="text-success fw-bold small">'.number_format($p['price'], 0, '.', ' ').'</div>
                        <div class="text-muted mt-1" style="font-size: 10px;">Zaxira: '.$p['stock'].'</div>
                    </div>
                </div>
            </div>';
        }
    } else {
        echo '<div class="col-12 text-center text-muted mt-5">Mahsulot topilmadi</div>';
    }
}