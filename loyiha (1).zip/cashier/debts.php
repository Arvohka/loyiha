<?php include 'includes/header.php'; ?>

<div class="container-fluid mt-4 px-4">
    <div class="row g-4">
        <div class="col-md-12 mb-2">
            <div class="card border-0 shadow-sm">
                <div class="card-body py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-danger"><i class="fas fa-hand-holding-usd me-2"></i> Qarzlar ro'yxati</h5>
                    <div class="d-flex gap-2">
                        <input type="text" id="debtSearch" class="form-control form-control-sm" placeholder="Mijoz ismi bilan qidirish...">
                        <button class="btn btn-sm btn-danger px-3" onclick="location.reload()"><i class="fas fa-sync"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card border-0 shadow-sm" style="border-radius: 12px; overflow: hidden;">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="debtsTable">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3 py-3">Mijoz Ismi</th>
                                    <th>Telefon</th>
                                    <th>Jami qarz</th>
                                    <th>Oxirgi yangilanish</th>
                                    <th class="text-end pe-3">Amallar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stmt = $db->prepare("SELECT * FROM debts WHERE owner_id = ? AND amount > 0 ORDER BY updated_at DESC");
                                $stmt->execute([$_SESSION['owner_id']]);
                                $debts = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                if ($debts):
                                    foreach ($debts as $debt): ?>
                                    <tr>
                                        <td class="ps-3 fw-bold"><?= htmlspecialchars($debt['customer_name']) ?></td>
                                        <td><?= htmlspecialchars($debt['customer_phone'] ?: '-') ?></td>
                                        <td class="text-danger fw-bold"><?= number_format($debt['amount']) ?> UZS</td>
                                        <td class="small text-muted"><?= date('d.m.Y H:i', strtotime($debt['updated_at'])) ?></td>
                                        <td class="text-end pe-3">
                                            <button onclick="viewDebtHistory('<?= htmlspecialchars($debt['customer_name']) ?>')" class="btn btn-sm btn-outline-primary shadow-sm me-1">
                                                <i class="fas fa-history"></i> Tarix
                                            </button>
                                            <button onclick="payDebt(<?= $debt['id'] ?>, '<?= htmlspecialchars($debt['customer_name']) ?>', <?= $debt['amount'] ?>)" class="btn btn-sm btn-success shadow-sm">
                                                <i class="fas fa-check-circle me-1"></i> To'lash
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; 
                                else: ?>
                                    <tr><td colspan="5" class="text-center py-5 text-muted">Hozircha qarzlar mavjud emas.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="payModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-danger text-white py-2">
                <h6 class="modal-title fw-bold">QARZNI TO'LASH</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="payForm">
                <div class="modal-body">
                    <input type="hidden" name="debt_id" id="debt_id">
                    <div class="mb-3 text-center">
                        <small class="text-muted">Mijoz:</small>
                        <h6 id="cust_name" class="fw-bold mb-0"></h6>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold">To'lov summasi:</label>
                        <input type="number" name="pay_amount" id="pay_amount" class="form-control border-danger fw-bold text-center" required>
                    </div>
                </div>
                <div class="modal-footer p-1 border-0">
                    <button type="submit" class="btn btn-danger w-100 py-2 fw-bold">TASDIQLASH</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="historyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white py-2">
                <h6 class="modal-title fw-bold">QARZGA OLINGAN MAHSULOTLAR</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0" id="history-content">
                </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function(){
    $("#debtSearch").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#debtsTable tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});

function payDebt(id, name, amount) {
    $('#debt_id').val(id);
    $('#cust_name').text(name);
    $('#pay_amount').val(amount);
    $('#payModal').modal('show');
}

function viewDebtHistory(name) {
    $('#historyModal').modal('show');
    $('#history-content').html('<div class="p-5 text-center"><i class="fas fa-spinner fa-spin fa-2x text-primary"></i></div>');
    $.get('api_debt_history.php', {customer_name: name}, function(res) {
        $('#history-content').html(res);
    });
}

$('#payForm').on('submit', function(e){
    e.preventDefault();
    $.post('api_pay_debt.php', $(this).serialize(), function(res){
        if(res.status == 'success'){
            location.reload();
        } else {
            alert(res.message);
        }
    }, 'json');
});
</script>
</body>
</html>