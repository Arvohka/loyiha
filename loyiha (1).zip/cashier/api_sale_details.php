<?php
session_start();
include '../config/db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    die("<div class='p-3 text-danger'>Ruxsat berilmagan yoki ma'lumot yetarli emas.</div>");
}

$sale_id = $_GET['id'];

try {
    // Savdo haqida umumiy ma'lumot
    $st_sale = $db->prepare("SELECT s.*, u.fullname FROM sales s LEFT JOIN users u ON s.cashier_id = u.id WHERE s.id = ?");
    $st_sale->execute([$sale_id]);
    $sale = $st_sale->fetch(PDO::FETCH_ASSOC);

    if (!$sale) {
        die("<div class='p-3 text-muted'>Savdo topilmadi.</div>");
    }

    // Savdo tarkibidagi mahsulotlar
    $st_items = $db->prepare("SELECT si.*, p.name FROM sale_items si LEFT JOIN products p ON si.product_id = p.id WHERE si.sale_id = ?");
    $st_items->execute([$sale_id]);
    $items = $st_items->fetchAll(PDO::FETCH_ASSOC);

    ?>
    <div class="p-3">
        <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
            <div>
                <small class="text-muted d-block">Sana va vaqt:</small>
                <strong><?= date('d.m.Y H:i', strtotime($sale['created_at'])) ?></strong>
            </div>
            <div class="text-end">
                <small class="text-muted d-block">To'lov turi:</small>
                <span class="badge bg-primary"><?= strtoupper($sale['pay_type']) ?></span>
            </div>
        </div>

        <table class="table table-sm align-middle">
            <thead class="table-light">
                <tr>
                    <th>Mahsulot</th>
                    <th class="text-center">Soni</th>
                    <th class="text-end">Narxi</th>
                    <th class="text-end">Jami</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td class="small fw-bold"><?= htmlspecialchars($item['name']) ?></td>
                    <td class="text-center"><?= $item['quantity'] ?></td>
                    <td class="text-end small"><?= number_format($item['price']) ?></td>
                    <td class="text-end fw-bold"><?= number_format($item['quantity'] * $item['price']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="table-light">
                    <th colspan="3" class="text-end">UMUMIY:</th>
                    <th class="text-end text-success"><?= number_format($sale['total_amount']) ?> UZS</th>
                </tr>
            </tfoot>
        </table>

        <div class="mt-3 small text-muted border-top pt-2">
            Kassir: <?= htmlspecialchars($sale['fullname']) ?>
        </div>
    </div>
    <?php

} catch (Exception $e) {
    echo "<div class='p-3 text-danger'>Xatolik: " . $e->getMessage() . "</div>";
}