<?php
session_start();
require_once '../core/Database.php';

if (!isset($_GET['id'])) die("Xato!");

$db = (new Database())->getConnection();
$sale_id = $_GET['id'];

// Sotuv ma'lumotlarini olish
$stmt = $db->prepare("SELECT s.*, st.fullname as cashier_name FROM sales s 
                      JOIN staff st ON s.cashier_id = st.id 
                      WHERE s.id = ?");
$stmt->execute([$sale_id]);
$sale = $stmt->fetch(PDO::FETCH_ASSOC);

// Sotilgan mahsulotlarni olish
$stmt_items = $db->prepare("SELECT si.*, p.name FROM sales_items si 
                            JOIN products p ON si.product_id = p.id 
                            WHERE si.sale_id = ?");
$stmt_items->execute([$sale_id]);
$items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Chek #<?= $sale_id ?></title>
    <style>
        body { font-family: 'Courier New', monospace; font-size: 12px; width: 58mm; margin: 0; padding: 5px; }
        .text-center { text-align: center; }
        .text-end { text-align: right; }
        .divider { border-top: 1px dashed #000; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; }
        .footer { margin-top: 10px; font-size: 10px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print();">

<div class="text-center">
    <strong>QARA TIZIM</strong><br>
    Sotuv cheki: #<?= $sale_id ?><br>
    Sana: <?= $sale['created_at'] ?>
</div>

<div class="divider"></div>

<table>
    <thead>
        <tr>
            <th align="left">Nomi</th>
            <th align="center">Soni</th>
            <th align="right">Narxi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($items as $item): ?>
        <tr>
            <td><?= $item['name'] ?></td>
            <td align="center"><?= $item['quantity'] ?></td>
            <td align="right"><?= number_format($item['price']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="divider"></div>

<div class="text-end">
    <strong>JAMI: <?= number_format($sale['total_amount']) ?> UZS</strong><br>
    To'lov: <?= strtoupper($sale['pay_type']) ?>
</div>

<div class="divider"></div>

<div class="footer text-center">
    Kassir: <?= $sale['cashier_name'] ?><br>
    Xaridingiz uchun rahmat!
</div>

<div class="no-print text-center" style="margin-top:20px;">
    <button onclick="window.close();">Yopish</button>
</div>

</body>
</html>