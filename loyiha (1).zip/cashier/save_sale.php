<?php
session_start();
include '../config/db.php';

// Post orqali kelayotgan ma'lumotlar
$items = $_POST['items'] ?? []; // Mahsulotlar ro'yxati
$total_amount = $_POST['total_amount'] ?? 0;
$pay_type = $_POST['pay_type'] ?? 'cash'; // cash, card, debt
$customer_name = $_POST['customer_name'] ?? null;
$customer_phone = $_POST['customer_phone'] ?? null;
$cashier_id = $_SESSION['user_id'];
$owner_id = $_SESSION['owner_id'];

if (empty($items)) {
    echo json_encode(['status' => 'error', 'message' => 'Savat bo\'sh']);
    exit;
}

try {
    $db->beginTransaction();

    // 1. Sales jadvaliga asosiy savdoni yozish
    $stmt = $db->prepare("INSERT INTO sales (cashier_id, owner_id, total_amount, pay_type, customer_name, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$cashier_id, $owner_id, $total_amount, $pay_type, $customer_name]);
    $sale_id = $db->lastInsertId();

    // 2. Mahsulotlarni sale_items jadvaliga va ombordan ayirish
    $st_item = $db->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    $st_prod = $db->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");

    foreach ($items as $item) {
        $st_item->execute([$sale_id, $item['id'], $item['qty'], $item['price']]);
        $st_prod->execute([$item['qty'], $item['id']]);
    }

    // 3. AGAR QARZ BO'LSA: Debts jadvaliga yozish yoki yangilash
    if ($pay_type === 'debt' && !empty($customer_name)) {
        // Avval shu mijoz borligini tekshirish
        $st_debt_check = $db->prepare("SELECT id FROM debts WHERE customer_name = ? AND owner_id = ?");
        $st_debt_check->execute([$customer_name, $owner_id]);
        $debt_row = $st_debt_check->fetch();

        if ($debt_row) {
            // Bor bo'lsa qarzini oshirish
            $st_debt_up = $db->prepare("UPDATE debts SET amount = amount + ?, customer_phone = ?, updated_at = NOW() WHERE id = ?");
            $st_debt_up->execute([$total_amount, $customer_phone, $debt_row['id']]);
        } else {
            // Yangi qarz yozish
            $st_debt_in = $db->prepare("INSERT INTO debts (owner_id, customer_name, customer_phone, amount, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())");
            $st_debt_in->execute([$owner_id, $customer_name, $customer_phone, $total_amount]);
        }
    }

    $db->commit();
    echo json_encode(['status' => 'success', 'sale_id' => $sale_id]);

} catch (Exception $e) {
    $db->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}