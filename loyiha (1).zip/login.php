<?php
require_once 'core/Database.php';
require_once 'core/Lang.php';
require_once 'core/Auth.php';

$db = (new Database())->getConnection();
$auth = new Auth($db);

$error = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($auth->login($username, $password)) {
        header("Location: dashboard.php");
        exit;
    } else {
        $error = Lang::t('login_error');
    }
}
?>
<!DOCTYPE html>
<html lang="<?= Lang::$current ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Lang::t('login_title') ?> | Hisobot.uz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; display: flex; align-items: center; height: 100vh; }
        .login-card { width: 100%; max-width: 400px; padding: 15px; margin: auto; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="text-center mb-4">
        <h2 class="fw-bold text-primary">HISOBOT.UZ</h2>
        <div class="btn-group mt-2">
            <a href="?lang=uz" class="btn btn-sm <?= Lang::$current == 'uz' ? 'btn-dark' : 'btn-outline-dark' ?>">UZ</a>
            <a href="?lang=ru" class="btn btn-sm <?= Lang::$current == 'ru' ? 'btn-dark' : 'btn-outline-dark' ?>">RU</a>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <h4 class="text-center mb-4"><?= Lang::t('login_title') ?></h4>
            
            <?php if($error): ?>
                <div class="alert alert-danger small text-center"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('username') ?></label>
                    <input type="text" name="username" class="form-control" placeholder="admin" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('password') ?></label>
                    <input type="password" name="password" class="form-control" placeholder="******" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2"><?= Lang::t('login_btn') ?></button>
            </form>
        </div>
    </div>
    <div class="text-center mt-3">
        <a href="index.php" class="text-decoration-none small">← <?= Lang::t('back_to_home') ?></a>
    </div>
</div>

</body>
</html>