<?php
include 'includes/header.php';

$tab = $_GET['tab'] ?? 'plans';

// Foydalanuvchining barcha obunalar tarixi
$history_stmt = $db->prepare("SELECT us.*, tp.name as tariff_name 
                             FROM user_subscriptions us 
                             JOIN tariff_plans tp ON us.tariff_id = tp.id 
                             WHERE us.user_id = ? 
                             ORDER BY us.id DESC");
$history_stmt->execute([$user_id]);
$history = $history_stmt->fetchAll(PDO::FETCH_ASSOC);

// Faol obunani tekshirish
$current_sub = null;
foreach ($history as $h) {
    if ($h['payment_status'] == 'paid' && strtotime($h['end_date']) > time()) {
        $current_sub = $h;
        break;
    }
}

$tariffs = $db->query("SELECT * FROM tariff_plans WHERE status = 'active' ORDER BY price ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="mb-4">
    <h4 class="fw-bold"><?= Lang::t('billing') ?></h4>
    <p class="text-muted small"><?= Lang::t('billing_desc') ?></p>
</div>

<ul class="nav nav-pills mb-4 bg-white p-2 rounded shadow-sm border" id="billingTabs">
    <li class="nav-item">
        <a class="nav-link <?= $tab == 'plans' ? 'active' : '' ?>" href="?tab=plans">
            <i class="fas fa-shopping-cart me-2"></i><?= Lang::t('subscription_plans') ?>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $tab == 'history' ? 'active' : '' ?>" href="?tab=history">
            <i class="fas fa-history me-2"></i><?= Lang::t('payment_history') ?>
            <?php if(count($history) > 0): ?>
                <span class="badge bg-secondary ms-1"><?= count($history) ?></span>
            <?php endif; ?>
        </a>
    </li>
</ul>

<div class="tab-content">
    <?php if ($tab == 'plans'): ?>
        <div class="row g-4">
            <?php foreach ($tariffs as $t): ?>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm border-0 <?= ($current_sub && $current_sub['tariff_id'] == $t['id']) ? 'border-primary border-2' : '' ?>" style="border-radius: 20px;">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <h6 class="text-uppercase fw-bold text-muted small"><?= htmlspecialchars($t['name']) ?></h6>
                            <h2 class="fw-bold text-primary mb-0"><?= number_format($t['price'], 0, '.', ' ') ?> <small class="fs-6">UZS</small></h2>
                            <span class="badge bg-light text-dark border mt-2"><?= $t['duration_months'] ?> <?= Lang::t('month') ?></span>
                        </div>
                        
                        <ul class="list-unstyled mb-4 small">
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> <?= Lang::t('cashiers') ?>: <b><?= $t['cashier_limit'] ?></b></li>
                            <li class="mb-2"><i class="fas fa-check text-success me-2"></i> <?= Lang::t('products_limit') ?>: <b><?= $t['product_limit'] ?></b></li>
                            <li class="mb-2"><i class="fas <?= $t['has_debt_book'] ? 'fa-check text-success' : 'fa-times text-danger' ?> me-2"></i> <?= Lang::t('debt_book') ?></li>
                            <li class="mb-2"><i class="fas <?= $t['has_click'] ? 'fa-check text-success' : 'fa-times text-danger' ?> me-2"></i> Click / Payme</li>
                        </ul>

                        <?php if ($current_sub && $current_sub['tariff_id'] == $t['id']): ?>
                            <button class="btn btn-success w-100 rounded-pill disabled"><i class="fas fa-check-circle me-1"></i> <?= Lang::t('active_now') ?></button>
                        <?php else: ?>
                            <button class="btn btn-primary w-100 rounded-pill" data-bs-toggle="modal" data-bs-target="#payModal<?= $t['id'] ?>"><?= Lang::t('choose_plan') ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="payModal<?= $t['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow" style="border-radius: 20px;">
                        <div class="modal-body text-center p-5">
                            <h5 class="fw-bold mb-4"><?= Lang::t('select_payment_method') ?></h5>
                            <div class="row g-3">
                                <div class="col-6"><a href="process_payment.php?method=click&tariff=<?= $t['id'] ?>" class="btn btn-outline-primary w-100 p-3"><img src="https://click.uz/static/img/logo.png" height="25"></a></div>
                                <div class="col-6"><a href="process_payment.php?method=payme&tariff=<?= $t['id'] ?>" class="btn btn-outline-info w-100 p-3"><img src="https://cdn.payme.uz/logo/payme_color.svg" height="25"></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    <?php elseif ($tab == 'history'): ?>
        <div class="card border-0 shadow-sm" style="border-radius: 15px;">
            <div class="table-responsive">
                <table class="table align-middle m-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4"><?= Lang::t('tariff_name') ?></th>
                            <th><?= Lang::t('payment_status') ?></th>
                            <th><?= Lang::t('start_date') ?></th>
                            <th><?= Lang::t('end_date') ?></th>
                            <th class="pe-4 text-end"><?= Lang::t('action') ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($history)): ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted"><?= Lang::t('no_history') ?></td></tr>
                        <?php endif; ?>
                        <?php foreach ($history as $h): ?>
                        <tr>
                            <td class="ps-4 fw-bold"><?= htmlspecialchars($h['tariff_name']) ?></td>
                            <td>
                                <span class="badge bg-<?= $h['payment_status'] == 'paid' ? 'success' : ($h['payment_status'] == 'pending' ? 'warning' : 'danger') ?>">
                                    <?= Lang::t($h['payment_status']) ?>
                                </span>
                            </td>
                            <td><?= date('d.m.Y H:i', strtotime($h['start_date'])) ?></td>
                            <td><?= date('d.m.Y', strtotime($h['end_date'])) ?></td>
                            <td class="pe-4 text-end">
                                <?php if($h['payment_status'] == 'pending'): ?>
                                    <a href="process_payment.php?retry=<?= $h['id'] ?>" class="btn btn-sm btn-primary"><?= Lang::t('pay_now') ?></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>