<?php
include 'includes/header.php';

// 1. Tarifdagi qarz tarixi muddatini tekshirish
$sub_stmt = $db->prepare("SELECT tp.has_debt_book, tp.debt_log_days FROM user_subscriptions us 
                          JOIN tariff_plans tp ON us.tariff_id = tp.id 
                          WHERE us.user_id = ? AND us.payment_status = 'paid' 
                          AND us.end_date > NOW() LIMIT 1");
$sub_stmt->execute([$user_id]);
$my_plan = $sub_stmt->fetch(PDO::FETCH_ASSOC);

if (!$my_plan || !$my_plan['has_debt_book']) {
    echo "<div class='alert alert-danger'>".Lang::t('not_allowed_method')."</div>";
    include 'includes/footer.php'; exit;
}

// 2. Qarzni yopish (To'lash)
if (isset($_GET['pay_id'])) {
    $pay_id = $_GET['pay_id'];
    $upd = $db->prepare("UPDATE orders SET payment_status = 'paid', updated_at = NOW() WHERE id = ? AND user_id = ?");
    $upd->execute([$pay_id, $user_id]);
    echo "<script>location.href='debts.php?success=1';</script>";
}

// 3. Qarzdorlar ro'yxati (Faqat tarif ruxsat bergan muddat ichidagilar)
$log_days = $my_plan['debt_log_days'];
$debt_stmt = $db->prepare("SELECT * FROM orders WHERE user_id = ? AND payment_method = 'debt' 
                           AND payment_status = 'pending' 
                           AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                           ORDER BY created_at DESC");
$debt_stmt->execute([$user_id, $log_days]);
$debts = $debt_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="mb-4">
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="fw-bold m-0"><?= Lang::t('debt_book') ?></h4>
        <span class="badge bg-warning text-dark p-2">
            <i class="fas fa-clock me-1"></i> 
            <?= str_replace(':days', $log_days, Lang::t('history_limit_info')) ?>
        </span>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="table-responsive">
        <table class="table align-middle m-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-4"><?= Lang::t('sale_date') ?></th>
                    <th><?= Lang::t('customer') ?></th>
                    <th><?= Lang::t('debt_amount') ?></th>
                    <th><?= Lang::t('status') ?></th>
                    <th class="pe-4 text-end"><?= Lang::t('action') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($debts)): ?>
                    <tr><td colspan="5" class="text-center py-5 text-muted"><?= Lang::t('no_data') ?></td></tr>
                <?php endif; ?>
                <?php foreach($debts as $d): ?>
                <tr>
                    <td class="ps-4">
                        <div class="small fw-bold"><?= date('d.m.Y', strtotime($d['created_at'])) ?></div>
                        <div class="text-muted" style="font-size: 11px;"><?= date('H:i', strtotime($d['created_at'])) ?></div>
                    </td>
                    <td><span class="fw-bold text-dark"><?= htmlspecialchars($d['customer_name'] ?? Lang::t('unknown')) ?></span></td>
                    <td class="text-danger fw-bold"><?= number_format($d['amount'], 0) ?> UZS</td>
                    <td><span class="badge bg-warning"><?= Lang::t('pending') ?></span></td>
                    <td class="pe-4 text-end">
                        <a href="?pay_id=<?= $d['id'] ?>" class="btn btn-sm btn-success rounded-pill px-3" onclick="return confirm('<?= Lang::t('confirm_payment') ?>')">
                            <i class="fas fa-check me-1"></i> <?= Lang::t('pay_debt') ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>



### Til fayllari uchun qo'shimcha kalitlar:
**uz.php:** `'customer' => 'Mijoz'`, `'status' => 'Holati'`, `'unknown' => 'Noma\'lum'`, `'confirm_payment' => 'Qarz to\'langanini tasdiqlaysizmi?'`  
**ru.php:** `'customer' => 'Клиент'`, `'status' => 'Статус'`, `'unknown' => 'Неизвестно'`, `'confirm_payment' => 'Подтверждаете оплату долга?'`

Keyingi qadam — **Foydalanuvchi interfeysini yakunlash va mobil ko'rinishga moslash (Responsive Design)** yoki **Cheklarni chiqarish (Print Receipt)** qismini qilamizmi?