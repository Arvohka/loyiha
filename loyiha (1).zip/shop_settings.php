<?php
include 'includes/header.php';

// Magazin ma'lumotlarini olish
$stmt = $db->prepare("SELECT * FROM shop_profiles WHERE owner_id = ?");
$stmt->execute([$user_id]);
$shop = $stmt->fetch(PDO::FETCH_ASSOC);

// Saqlash jarayoni
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_shop'])) {
    if ($shop) {
        $sql = "UPDATE shop_profiles SET shop_name = ?, address = ?, phone = ? WHERE owner_id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$_POST['shop_name'], $_POST['address'], $_POST['phone'], $user_id]);
    } else {
        $sql = "INSERT INTO shop_profiles (owner_id, shop_name, address, phone) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        $stmt->execute([$user_id, $_POST['shop_name'], $_POST['address'], $_POST['phone']]);
    }
    echo "<script>location.href='shop_settings.php?success=1';</script>";
}
?>

<div class="mb-4">
    <h4 class="fw-bold"><?= Lang::t('shop_settings') ?></h4>
    <p class="text-muted small"><?= Lang::t('shop_settings_desc') ?></p>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm p-4" style="border-radius: 15px;">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('shop_name') ?></label>
                    <input type="text" name="shop_name" class="form-control" value="<?= $shop['shop_name'] ?? '' ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('shop_phone') ?></label>
                    <input type="text" name="phone" class="form-control" value="<?= $shop['phone'] ?? '' ?>" placeholder="+998">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('shop_address') ?></label>
                    <textarea name="address" class="form-control" rows="3"><?= $shop['address'] ?? '' ?></textarea>
                </div>
                <hr>
                <button type="submit" name="save_shop" class="btn btn-primary px-5 rounded-pill">
                    <?= Lang::t('save_changes') ?>
                </button>
            </form>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card border-0 bg-primary text-white p-4 h-100 shadow-sm" style="border-radius: 15px;">
            <h5 class="fw-bold mb-3"><?= Lang::t('shop_info') ?></h5>
            <p class="small opacity-75"><?= Lang::t('shop_info_help') ?></p>
            <ul class="list-unstyled mt-4">
                <li class="mb-2"><i class="fas fa-id-card me-2"></i> ID: #<?= $user_id ?></li>
                <li class="mb-2"><i class="fas fa-store me-2"></i> <?= $shop['shop_name'] ?? Lang::t('not_set') ?></li>
                <li class="mb-2"><i class="fas fa-map-marker-alt me-2"></i> <?= $shop['address'] ?? Lang::t('not_set') ?></li>
            </ul>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>