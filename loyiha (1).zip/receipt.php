<?php
require_once 'core/Database.php';
require_once 'core/Lang.php';
require_once 'core/Auth.php';

Auth::check();
$db = (new Database())->getConnection();

$order_id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];

// Buyurtma va do'kon ma'lumotlarini olish
$stmt = $db->prepare("SELECT o.*, s.shop_name, s.address as shop_address, s.phone as shop_phone 
                      FROM orders o 
                      LEFT JOIN shop_profiles s ON o.user_id = s.owner_id 
                      WHERE o.id = ? AND o.user_id = ?");
$stmt->execute([$order_id, $user_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) { die("Order not found"); }

// Mahsulotlarni olish
$items_stmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$items_stmt->execute([$order_id]);
$items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Check #<?= $order_id ?></title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; width: 58mm; margin: 0; padding: 5px; font-size: 12px; }
        .text-center { text-align: center; }
        .fw-bold { font-weight: bold; }
        .hr { border-bottom: 1px dashed #000; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; }
        .footer { margin-top: 15px; font-size: 10px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print()">

<div class="no-print" style="margin-bottom: 10px;">
    <button onclick="window.print()"><?= Lang::t('print') ?></button>
    <a href="pos.php"><?= Lang::t('back') ?></a>
</div>

<div class="text-center">
    <h3 style="margin: 0;"><?= htmlspecialchars($order['shop_name'] ?? 'HISOBOT.UZ') ?></h3>
    <div style="font-size: 10px;"><?= htmlspecialchars($order['shop_address'] ?? '') ?></div>
    <div style="font-size: 10px;"><?= htmlspecialchars($order['shop_phone'] ?? '') ?></div>
</div>

<div class="hr"></div>
<div><b>№:</b> <?= $order['id'] ?></div>
<div><b>Sana:</b> <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></div>
<div class="hr"></div>

<table>
    <?php foreach($items as $item): ?>
    <tr>
        <td colspan="2"><?= htmlspecialchars($item['product_name']) ?></td>
    </tr>
    <tr>
        <td><?= $item['quantity'] ?> x <?= number_format($item['price'], 0) ?></td>
        <td style="text-align: right;"><?= number_format($item['quantity'] * $item['price'], 0) ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<div class="hr"></div>
<div style="display: flex; justify-content: space-between; font-weight: bold;">
    <span><?= Lang::t('total_amount') ?>:</span>
    <span><?= number_format($order['amount'], 0) ?></span>
</div>
<div style="display: flex; justify-content: space-between; font-size: 11px;">
    <span><?= Lang::t('payment_type') ?>:</span>
    <span><?= Lang::t($order['payment_method']) ?></span>
</div>

<div class="hr"></div>
<div class="text-center footer">
    <?= Lang::t('thanks_message') ?><br>
    <b>www.hisobot.uz</b>
</div>

</body>
</html>