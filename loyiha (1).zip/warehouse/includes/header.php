<?php
session_start();
require_once '../core/Database.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['warehouseman', 'admin'])) {
    header("Location: login.php");
    exit;
}

$db = (new Database())->getConnection();
$fullname = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ombor Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        body { background: #f4f7f6; margin: 0; }
        .sidebar { min-height: 100vh; background: #2c3e50; color: white; position: fixed; width: 240px; z-index: 1000; }
        .nav-link { color: rgba(255,255,255,0.7); padding: 12px 20px; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { color: white; background: rgba(255,255,255,0.1); }
        .topbar { margin-left: 240px; background: white; height: 70px; display: flex; align-items: center; justify-content: flex-end; padding: 0 30px; box-shadow: 0 2px 15px rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 999; }
        .main-content { margin-left: 240px; padding: 30px; min-height: calc(100vh - 70px); }
        .user-profile { display: flex; align-items: center; gap: 15px; }
        .user-info { text-align: right; line-height: 1.2; }
        .btn-action { color: #555; text-decoration: none; font-size: 18px; transition: 0.3s; padding: 8px; border-radius: 50%; }
        .btn-action:hover { background: #f8f9fa; color: #000; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 border-bottom border-secondary text-center">
        <div class="bg-light d-inline-block p-2 rounded-circle mb-2">
            <i class="fas fa-warehouse text-dark"></i>
        </div>
        <h6 class="fw-bold mb-0">OMBOR TIZIMI</h6>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="index.php"><i class="fas fa-th-large me-2"></i> Asosiy panel</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : '' ?>" href="products.php"><i class="fas fa-boxes me-2"></i> Mahsulotlar</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'stock_in.php' ? 'active' : '' ?>" href="stock_in.php"><i class="fas fa-plus-circle me-2"></i> Kirim qilish</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : '' ?>" href="categories.php"><i class="fas fa-tags me-2"></i> Kategoriyalar</a></li>
    </ul>
</div>

<div class="topbar">
    <div class="user-profile">
        <div class="dropdown me-2">
            <a href="#" class="btn-action" data-bs-toggle="dropdown"><i class="fas fa-globe"></i></a>
            <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                <li><a class="dropdown-item small" href="?lang=uz">O'zbekcha</a></li>
                <li><a class="dropdown-item small" href="?lang=ru">Русский</a></li>
            </ul>
        </div>
        <div class="user-info">
            <div class="fw-bold text-dark small"><?= htmlspecialchars($fullname) ?></div>
            <span class="text-success small" style="font-size: 11px;"><i class="fas fa-circle me-1" style="font-size: 8px;"></i> Online</span>
        </div>
        <div class="ms-3 border-start ps-3">
            <a href="logout.php" class="btn-action text-danger" title="Chiqish"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
</div>
<div class="main-content">