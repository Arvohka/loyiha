<?php
session_start();
require_once '../core/Database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $db = (new Database())->getConnection();
    
    $stmt = $db->prepare("SELECT * FROM staff WHERE username = ?");
    $stmt->execute([$username]);
    $worker = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($worker && password_verify($password, $worker['password'])) {
        // Rolni 'warehouseman' yoki 'admin' ekanligini tekshiramiz
        if ($worker['role'] === 'warehouseman' || $worker['role'] === 'admin') {
            $_SESSION['user_id'] = $worker['id'];
            $_SESSION['owner_id'] = $worker['owner_id'];
            $_SESSION['fullname'] = $worker['fullname'];
            $_SESSION['role'] = $worker['role'];
            header("Location: index.php");
            exit;
        } else {
            $error = "Sizda omborga kirish huquqi yo'q! Rolingiz: " . $worker['role'];
        }
    } else {
        $error = "Login yoki parol xato!";
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ombor Tizimi - Kirish</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background: #f4f7f6; height: 100vh; display: flex; align-items: center; justify-content: center; margin: 0; }
        .login-card { width: 100%; max-width: 400px; border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); background: #fff; }
        .btn-warehouse { background: #2c3e50; color: white; border-radius: 8px; padding: 12px; border: none; transition: 0.3s; }
        .btn-warehouse:hover { background: #1a252f; }
        .icon-box { background: #2c3e50; color: white; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; border-radius: 50%; margin: 0 auto 15px; }
    </style>
</head>
<body>

<div class="card login-card p-4">
    <div class="text-center mb-4">
        <div class="icon-box">
            <i class="fas fa-warehouse fa-lg"></i>
        </div>
        <h4 class="fw-bold text-dark text-uppercase mb-1">Ombor boshqaruvi</h4>
        <p class="text-muted small">Xodim akkaunti orqali kiring</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger small py-2 border-0 text-center"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="small fw-bold mb-1 text-secondary">Foydalanuvchi nomi</label>
            <div class="input-group border rounded-2">
                <span class="input-group-text bg-white border-0"><i class="fas fa-user-tie text-muted small"></i></span>
                <input type="text" name="username" class="form-control border-0 shadow-none" placeholder="Login" required autofocus>
            </div>
        </div>
        <div class="mb-4">
            <label class="small fw-bold mb-1 text-secondary">Parol</label>
            <div class="input-group border rounded-2">
                <span class="input-group-text bg-white border-0"><i class="fas fa-lock text-muted small"></i></span>
                <input type="password" name="password" class="form-control border-0 shadow-none" placeholder="********" required>
            </div>
        </div>
        <button type="submit" class="btn btn-warehouse w-100 fw-bold shadow-sm">
            <i class="fas fa-sign-in-alt me-2"></i> TIZIMGA KIRISH
        </button>
    </form>
</div>

</body>
</html>