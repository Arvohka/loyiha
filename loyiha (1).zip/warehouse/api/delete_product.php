<?php
session_start();
require_once '../../core/Database.php';

header('Content-Type: application/json');

if (isset($_GET['id'])) {
    try {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        
        if ($stmt->execute([$_GET['id']])) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'O\'chirishda xatolik']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'ID topilmadi']);
}