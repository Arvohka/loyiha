<?php
session_start();
require_once '../../core/Database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = (new Database())->getConnection();
    $sql = "UPDATE products SET barcode=?, name=?, category=?, unit=?, cost_price=?, selling_price=?, stock=? WHERE id=?";
    $stmt = $db->prepare($sql);
    
    if ($stmt->execute([
        $_POST['barcode'], $_POST['name'], $_POST['category'], 
        $_POST['unit'], $_POST['cost_price'], $_POST['selling_price'], 
        $_POST['stock'], $_POST['id']
    ])) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
}