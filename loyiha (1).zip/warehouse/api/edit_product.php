<?php
session_start();
require_once '../../core/Database.php';
header('Content-Type: application/json');

if (isset($_GET['id'])) {
    $db = (new Database())->getConnection();
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($product);
}