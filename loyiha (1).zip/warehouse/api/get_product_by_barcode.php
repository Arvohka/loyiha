<?php
session_start();
require_once '../../core/Database.php';

header('Content-Type: application/json');

if (isset($_GET['barcode'])) {
    try {
        $db = (new Database())->getConnection();
        $stmt = $db->prepare("SELECT * FROM products WHERE barcode = ? LIMIT 1");
        $stmt->execute([$_GET['barcode']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            echo json_encode(['status' => 'success', 'data' => $product]);
        } else {
            echo json_encode(['status' => 'not_found']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}