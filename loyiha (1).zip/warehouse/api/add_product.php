<?php
session_start();
require_once '../../core/Database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = (new Database())->getConnection();
    
    $barcode = $_POST['barcode'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $unit = $_POST['unit'];
    $cost_price = $_POST['cost_price'];
    $selling_price = $_POST['selling_price'];
    $stock = $_POST['stock'];
    $owner_id = $_SESSION['owner_id'] ?? 1; // Agar owner_id tizimingizda bo'lsa

    $sql = "INSERT INTO products (barcode, name, category, unit, cost_price, selling_price, stock, owner_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $db->prepare($sql);
    
    if ($stmt->execute([$barcode, $name, $category, $unit, $cost_price, $selling_price, $stock, $owner_id])) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Saqlashda xatolik yuz berdi']);
    }
}