<?php include 'includes/header.php'; ?>

<div class="card border-0 shadow-sm p-5 text-center bg-white" style="border-radius: 15px;">
    <div class="mb-3"><i class="fas fa-rocket fa-3x text-primary opacity-25"></i></div>
    <h5 class="fw-bold">Ombor boshqaruviga xush kelibsiz!</h5>
    <p class="text-muted">Bugungi sana: <strong><?= date('d.m.Y') ?></strong></p>
</div>

<?php include 'includes/footer.php'; ?>