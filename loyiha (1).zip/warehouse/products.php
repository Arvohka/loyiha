<?php include 'includes/header.php'; ?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card border-0 shadow-sm p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-dark"><i class="fas fa-boxes me-2"></i> Mahsulotlar boshqaruvi</h5>
                    <div class="d-flex gap-2">
                        <input type="text" id="searchProduct" class="form-control form-control-sm" placeholder="Qidirish...">
                        <button class="btn btn-primary btn-sm px-3" onclick="prepareAddModal()">
                            <i class="fas fa-plus me-1"></i> Yangi mahsulot
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm" style="border-radius: 12px; overflow: hidden;">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="productTable">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="ps-4 py-3 small text-uppercase">Shtrix-kod</th>
                            <th class="small text-uppercase">Nomi</th>
                            <th class="small text-uppercase">Kategoriya</th>
                            <th class="small text-uppercase">Narxi (Kelish/Sotish)</th>
                            <th class="small text-uppercase">Qoldiq</th>
                            <th class="text-end pe-4 small text-uppercase">Amallar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $db->query("SELECT * FROM products ORDER BY id DESC");
                        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($products as $p):
                        ?>
                        <tr>
                            <td class="ps-4"><code><?= htmlspecialchars($p['barcode']) ?></code></td>
                            <td class="fw-bold"><?= htmlspecialchars($p['name']) ?></td>
                            <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($p['category']) ?></span></td>
                            <td>
                                <small class="text-muted"><?= number_format($p['cost_price']) ?></small> / 
                                <span class="text-success fw-bold"><?= number_format($p['selling_price']) ?></span>
                            </td>
                            <td>
                                <span class="badge <?= $p['stock'] <= 5 ? 'bg-danger' : 'bg-info' ?>">
                                    <?= $p['stock'] ?> <?= $p['unit'] ?>
                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <button class="btn btn-sm btn-light border" onclick="editProduct(<?= $p['id'] ?>)"><i class="fas fa-edit text-primary"></i></button>
                                <button class="btn btn-sm btn-light border" onclick="deleteProduct(<?= $p['id'] ?>)"><i class="fas fa-trash text-danger"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="productModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold small text-uppercase" id="modalTitle">Mahsulot</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" onclick="stopScanner()"></button>
            </div>
            <form id="productForm">
                <input type="hidden" name="id" id="productId">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="small fw-bold mb-1">Shtrix-kod (Skaner yoki Kamera)</label>
                        <div class="input-group">
                            <input type="text" name="barcode" id="barcode" class="form-control" required>
                            <button class="btn btn-warning text-white" type="button" id="scanBtn" onclick="toggleScanner()">
                                <i class="fas fa-camera"></i>
                            </button>
                        </div>
                        <div id="reader" style="width: 100%; display: none;" class="mt-2 border rounded overflow-hidden"></div>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold mb-1">Mahsulot nomi</label>
                        <input type="text" name="name" id="name" class="form-control" required>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="small fw-bold mb-1">Kategoriya</label>
                            <input type="text" name="category" id="category" class="form-control">
                        </div>
                        <div class="col-6">
                            <label class="small fw-bold mb-1">O'lchov birligi</label>
                            <select name="unit" id="unit" class="form-select">
                                <option value="ta">ta</option>
                                <option value="kg">kg</option>
                                <option value="litr">litr</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="small fw-bold mb-1">Kelish narxi</label>
                            <input type="number" name="cost_price" id="cost_price" class="form-control" step="0.01" required>
                        </div>
                        <div class="col-6">
                            <label class="small fw-bold mb-1">Sotish narxi</label>
                            <input type="number" name="selling_price" id="selling_price" class="form-control" step="0.01" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold mb-1">Mavjud miqdor</label>
                        <input type="number" name="stock" id="stock" class="form-control" value="0" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal" onclick="stopScanner()">Bekor qilish</button>
                    <button type="submit" class="btn btn-primary btn-sm px-4">Saqlash</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let modalInstance;
let html5QrCode;

document.addEventListener('DOMContentLoaded', function() {
    modalInstance = new bootstrap.Modal(document.getElementById('productModal'));
});

function toggleScanner() {
    const readerDiv = document.getElementById('reader');
    if (readerDiv.style.display === 'none') {
        startScanner();
    } else {
        stopScanner();
    }
}

function startScanner() {
    document.getElementById('reader').style.display = 'block';
    html5QrCode = new Html5Qrcode("reader");
    const config = { fps: 10, qrbox: { width: 250, height: 150 } };

    html5QrCode.start({ facingMode: "environment" }, config, (decodedText) => {
        document.getElementById('barcode').value = decodedText;
        checkProductByBarcode(decodedText); // Bazadan tekshirish
        stopScanner();
        if (navigator.vibrate) navigator.vibrate(100);
    }).catch(err => {
        console.error(err);
        alert("Kamera ishga tushmadi!");
    });
}

function stopScanner() {
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => {
            document.getElementById('reader').style.display = 'none';
        });
    } else {
        document.getElementById('reader').style.display = 'none';
    }
}

// Shtrix-kod orqali mahsulotni aniqlash va formani to'ldirish
function checkProductByBarcode(barcode) {
    if (!barcode || document.getElementById('productId').value !== '') return;

    fetch('api/get_product_by_barcode.php?barcode=' + barcode)
    .then(res => res.json())
    .then(result => {
        if (result.status === 'success') {
            const data = result.data;
            document.getElementById('name').value = data.name;
            document.getElementById('category').value = data.category;
            document.getElementById('unit').value = data.unit;
            document.getElementById('cost_price').value = data.cost_price;
            document.getElementById('selling_price').value = data.selling_price;
            document.getElementById('stock').focus();
        }
    });
}

// Shtrix-kod qo'lda yozilganda ham tekshirish
document.getElementById('barcode').addEventListener('change', function() {
    checkProductByBarcode(this.value);
});

function prepareAddModal() {
    stopScanner();
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('modalTitle').innerText = "Yangi mahsulot qo'shish";
    modalInstance.show();
}

function editProduct(id) {
    stopScanner();
    fetch('api/edit_product.php?id=' + id)
    .then(res => res.json())
    .then(data => {
        document.getElementById('productId').value = data.id;
        document.getElementById('barcode').value = data.barcode;
        document.getElementById('name').value = data.name;
        document.getElementById('category').value = data.category;
        document.getElementById('unit').value = data.unit;
        document.getElementById('cost_price').value = data.cost_price;
        document.getElementById('selling_price').value = data.selling_price;
        document.getElementById('stock').value = data.stock;
        document.getElementById('modalTitle').innerText = "Mahsulotni tahrirlash";
        modalInstance.show();
    });
}

document.getElementById('productForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const id = document.getElementById('productId').value;
    const url = id ? 'api/update_product.php' : 'api/add_product.php';
    fetch(url, { method: 'POST', body: new FormData(this) })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') location.reload();
        else alert(data.message);
    });
});

document.getElementById('searchProduct').addEventListener('keyup', function() {
    let val = this.value.toLowerCase();
    document.querySelectorAll('#productTable tbody tr').forEach(tr => {
        tr.style.display = tr.innerText.toLowerCase().includes(val) ? '' : 'none';
    });
});

function deleteProduct(id) {
    if(confirm('O\'chirilsinmi?')) {
        fetch('api/delete_product.php?id=' + id).then(() => location.reload());
    }
}
</script>

<?php include 'includes/footer.php'; ?>