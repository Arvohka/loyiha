<?php
require_once 'core/Database.php';
require_once 'core/Lang.php';
require_once 'core/Auth.php';

Auth::check();
Lang::init();

$db = (new Database())->getConnection();
$user_id = $_SESSION['user_id'];

// Obuna holatini tekshirish
$sub_stmt = $db->prepare("SELECT tp.* FROM user_subscriptions us 
                          JOIN tariff_plans tp ON us.tariff_id = tp.id 
                          WHERE us.user_id = ? AND us.payment_status = 'paid' 
                          AND us.end_date > NOW() LIMIT 1");
$sub_stmt->execute([$user_id]);
$has_access = $sub_stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="<?= Lang::$current ?>">
<head>
    <meta charset="UTF-8">
    <title><?= Lang::t('dashboard') ?> | Hisobot.uz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar { min-width: 250px; background: #2c3e50; min-height: 100vh; color: white; position: sticky; top: 0; }
        .sidebar a { color: #bdc3c7; text-decoration: none; padding: 15px 20px; display: block; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: white; border-left: 4px solid #3498db; }
        .card-box { border-radius: 15px; border: none; transition: 0.3s; }
        .card-box:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="bg-light">

<div class="d-flex">
    <div class="sidebar shadow">
        <div class="p-4 text-center">
            <h4 class="fw-bold">HISOBOT.UZ</h4>
            <hr>
        </div>
        
        <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-chart-line me-2"></i> <?= Lang::t('dashboard') ?>
        </a>

        <a href="billing.php" class="<?= basename($_SERVER['PHP_SELF']) == 'billing.php' ? 'active' : '' ?>">
            <i class="fas fa-credit-card me-2"></i> <?= Lang::t('billing') ?>
        </a>

        <?php if ($has_access): ?>
            <a href="pos.php" class="<?= basename($_SERVER['PHP_SELF']) == 'pos.php' ? 'active' : '' ?>">
                <i class="fas fa-cash-register me-2"></i> <?= Lang::t('pos') ?>
            </a>
            
            <a href="inventory.php" class="<?= basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : '' ?>">
                <i class="fas fa-boxes me-2"></i> <?= Lang::t('inventory') ?>
            </a>
            
            <a href="finance.php" class="<?= basename($_SERVER['PHP_SELF']) == 'finance.php' ? 'active' : '' ?>">
                <i class="fas fa-wallet me-2"></i> <?= Lang::t('finance') ?>
            </a>

            <a href="debts.php" class="<?= basename($_SERVER['PHP_SELF']) == 'debts.php' ? 'active' : '' ?>">
                <i class="fas fa-book me-2"></i> <?= Lang::t('debt_book') ?>
            </a>

            <a href="users_staff.php" class="<?= basename($_SERVER['PHP_SELF']) == 'users_staff.php' ? 'active' : '' ?>">
                <i class="fas fa-users me-2"></i> <?= Lang::t('staff_management') ?>
            </a>

            <a href="shop_settings.php" class="<?= basename($_SERVER['PHP_SELF']) == 'shop_settings.php' ? 'active' : '' ?>">
                <i class="fas fa-cog me-2"></i> <?= Lang::t('shop_settings') ?>
            </a>
        <?php endif; ?>

        <a href="logout.php" class="text-danger mt-5">
            <i class="fas fa-sign-out-alt me-2"></i> <?= Lang::t('logout') ?>
        </a>
    </div>

    <div class="flex-grow-1">
        <nav class="navbar navbar-expand navbar-white bg-white shadow-sm mb-4 p-3">
            <div class="container-fluid">
                <span class="fw-bold"><?= Lang::t('welcome') ?>, <?= $_SESSION['fullname'] ?></span>
                <div class="ms-auto">
                    <a href="?lang=uz" class="btn btn-sm btn-light">UZ</a>
                    <a href="?lang=ru" class="btn btn-sm btn-light">RU</a>
                </div>
            </div>
        </nav>
        <div class="container-fluid px-4">