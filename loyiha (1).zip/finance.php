<?php
include 'includes/header.php';

// 1. Umumiy moliya statistikasi
$total_income = $db->prepare("SELECT SUM(amount) FROM orders WHERE user_id = ? AND payment_status = 'paid'");
$total_income->execute([$user_id]);
$income = $total_income->fetchColumn() ?? 0;

$total_expense = $db->prepare("SELECT SUM(amount) FROM expenses WHERE user_id = ?");
$total_expense->execute([$user_id]);
$expense = $total_expense->fetchColumn() ?? 0;

// 2. Xarajat qo'shish jarayoni
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_expense'])) {
    $ins = $db->prepare("INSERT INTO expenses (user_id, title, amount, category, created_at) VALUES (?, ?, ?, ?, NOW())");
    $ins->execute([$user_id, $_POST['title'], $_POST['amount'], $_POST['category']]);
    echo "<script>location.href='finance.php?success=1';</script>";
}

$expenses_list = $db->prepare("SELECT * FROM expenses WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$expenses_list->execute([$user_id]);
?>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 bg-white border-start border-success border-5">
            <small class="text-muted fw-bold text-uppercase"><?= Lang::t('total_income') ?></small>
            <h3 class="fw-bold text-success mb-0"><?= number_format($income, 0) ?> <small class="fs-6">UZS</small></h3>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 bg-white border-start border-danger border-5">
            <small class="text-muted fw-bold text-uppercase"><?= Lang::t('total_expense') ?></small>
            <h3 class="fw-bold text-danger mb-0"><?= number_format($expense, 0) ?> <small class="fs-6">UZS</small></h3>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 bg-primary text-white">
            <small class="opacity-75 fw-bold text-uppercase"><?= Lang::t('net_profit') ?></small>
            <h3 class="fw-bold mb-0"><?= number_format($income - $expense, 0) ?> <small class="fs-6">UZS</small></h3>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold mb-3"><?= Lang::t('add_expense') ?></h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="small fw-bold"><?= Lang::t('expense_title') ?></label>
                    <input type="text" name="title" class="form-control" placeholder="Masalan: Ijara, Ish haqi" required>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold"><?= Lang::t('amount') ?></label>
                    <input type="number" name="amount" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="small fw-bold"><?= Lang::t('category') ?></label>
                    <select name="category" class="form-select">
                        <option value="rent"><?= Lang::t('rent') ?></option>
                        <option value="salary"><?= Lang::t('salary') ?></option>
                        <option value="utilities"><?= Lang::t('utilities') ?></option>
                        <option value="other"><?= Lang::t('other') ?></option>
                    </select>
                </div>
                <button type="submit" name="add_expense" class="btn btn-danger w-100 rounded-pill"><?= Lang::t('save') ?></button>
            </form>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-header bg-white fw-bold border-0 py-3"><?= Lang::t('recent_expenses') ?></div>
            <table class="table align-middle m-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4"><?= Lang::t('expense_title') ?></th>
                        <th><?= Lang::t('category') ?></th>
                        <th><?= Lang::t('amount') ?></th>
                        <th class="pe-4"><?= Lang::t('date') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($expenses_list->fetchAll() as $ex): ?>
                    <tr>
                        <td class="ps-4 fw-bold"><?= htmlspecialchars($ex['title']) ?></td>
                        <td><span class="badge bg-light text-dark border"><?= Lang::t($ex['category']) ?></span></td>
                        <td class="text-danger fw-bold">-<?= number_format($ex['amount'], 0) ?></td>
                        <td class="pe-4 small text-muted"><?= date('d.m.Y', strtotime($ex['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>