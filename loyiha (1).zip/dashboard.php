<?php
include 'includes/header.php';

// Statistika: Daromad va Xarajat
$stats_stmt = $db->prepare("SELECT type, SUM(amount) as total FROM reports WHERE user_id = ? GROUP BY type");
$stats_stmt->execute([$user_id]);
$stats = $stats_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$income = $stats['income'] ?? 0;
$expense = $stats['expense'] ?? 0;

$inventory_stmt = $db->query("SELECT SUM(stock_quantity) as total_items FROM inventory");
$total_stock = $inventory_stmt->fetch(PDO::FETCH_ASSOC)['total_items'] ?? 0;
?>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card card-box bg-white p-4 shadow-sm border-start border-success border-5">
            <small class="text-muted fw-bold"><?= Lang::t('income') ?></small>
            <h3 class="fw-bold text-success"><?= number_format($income, 0, '.', ' ') ?> UZS</h3>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-box bg-white p-4 shadow-sm border-start border-danger border-5">
            <small class="text-muted fw-bold"><?= Lang::t('expense') ?></small>
            <h3 class="fw-bold text-danger"><?= number_format($expense, 0, '.', ' ') ?> UZS</h3>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-box bg-white p-4 shadow-sm border-start border-primary border-5">
            <small class="text-muted fw-bold"><?= Lang::t('inventory') ?> (<?= Lang::t('qty') ?>)</small>
            <h3 class="fw-bold text-primary"><?= $total_stock ?> dona</h3>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-7">
        <div class="card card-box shadow-sm p-4 bg-white">
            <h5 class="fw-bold mb-4"><?= Lang::t('finance_chart') ?></h5>
            <canvas id="financeChart" height="200"></canvas>
        </div>
    </div>
    <div class="col-md-5">
        <div class="card card-box shadow-sm p-4 bg-white h-100">
            <h5 class="fw-bold mb-4"><?= Lang::t('recent_activities') ?></h5>
            <p class="text-muted small">Hozircha ma'lumot yo'q</p>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('financeChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['<?= Lang::t('income') ?>', '<?= Lang::t('expense') ?>'],
        datasets: [{
            label: 'UZS',
            data: [<?= $income ?>, <?= $expense ?>],
            backgroundColor: ['#2ecc71', '#e74c3c'],
            borderRadius: 10
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>

<?php include 'includes/footer.php'; ?>