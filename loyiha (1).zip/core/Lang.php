<?php
class Lang {
    private static $translations = [];
    public static $current;

    public static function init() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (isset($_GET['lang'])) $_SESSION['lang'] = $_GET['lang'];
        self::$current = $_SESSION['lang'] ?? 'uz';

        $file = __DIR__ . "/../languages/" . self::$current . ".php";
        if (file_exists($file)) {
            self::$translations = require $file;
        }
    }

    // Xatoni to'g'irlaydigan asosiy metod
    public static function t($key) {
        return self::$translations[$key] ?? $key;
    }

    public static function db($row, $field) {
        $key = $field . '_' . self::$current;
        return $row[$key] ?? ($row[$field . '_uz'] ?? '');
    }
}
Lang::init();