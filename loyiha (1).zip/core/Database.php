<?php
class Database {
    private $host = "localhost";
    private $db_name = "mobi_crm1_mobhost"; // ISPmanager'da ochilgan baza nomi
    private $username = "mobi_crm1_mobhost"; // Baza foydalanuvchisi
    private $password = "satura1988";     // Baza paroli
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8mb4");
        } catch(PDOException $exception) {
            die("Baza bilan aloqa yo'q: " . $exception->getMessage());
        }
        return $this->conn;
    }
}