<?php

class Auth {
    /**
     * @var PDO
     */
    private $db;

    /**
     * Konstruktor: Bazaga ulanishni qabul qiladi va sessiyani boshlaydi.
     * * @param PDO|null $db
     */
    public function __construct($db = null) {
        $this->db = $db;
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Sahifani himoya qilish: Foydalanuvchi tizimga kirmagan bo'lsa, 
     * uni login.php sahifasiga yo'naltiradi.
     */
    public static function check() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id'])) {
            header("Location: login.php");
            exit;
        }
    }

    /**
     * Tizimga kirish mantiqi: Ma'lumotlar faqat bazadagi users jadvalidan olinadi.
     * * @param string $username
     * @param string $password
     * @return bool
     */
    public function login($username, $password) {
        if (!$this->db) {
            return false;
        }

        try {
            // Ma'lumotlarni faqat bazadan qidiramiz
            $stmt = $this->db->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Parol hash qilingan bo'lsa password_verify, aks holda oddiy solishtiruv (faqat test uchun)
                $isValid = false;
                if (password_verify($password, $user['password'])) {
                    $isValid = true;
                } elseif ($password === $user['password']) {
                    $isValid = true;
                }

                if ($isValid) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'] ?? 'admin';
                    
                    return true;
                }
            }
        } catch (PDOException $e) {
            return false;
        }

        return false;
    }

    /**
     * Foydalanuvchi ma'lumotlarini sessiyadan olish
     * * @return array|null
     */
    public static function user() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return isset($_SESSION['user_id']) ? $_SESSION : null;
    }

    /**
     * Tizimdan chiqish mantiqi
     */
    public static function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Barcha sessiya o'zgaruvchilarini tozalash
        $_SESSION = array();

        // Sessiya kukilarini o'chirish
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }

        session_destroy();
        header("Location: ../index.php");
        exit;
    }
}