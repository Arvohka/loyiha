<?php
// MUHIM: db.php faylingiz qayerda joylashgan bo'lsa o'sha yo'lni yozing
// Agar /admin papkasida bo'lsangiz:
require_once '../includes/db.php'; 

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->execute([$id]);
}

header("Location: categories.php");
exit;