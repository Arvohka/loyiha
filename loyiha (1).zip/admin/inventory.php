<?php
require_once 'core/Database.php';
require_once 'core/Lang.php';
require_once 'core/Auth.php';

Auth::check();

$db = (new Database())->getConnection();

// Mahsulot qo'shish mantiqi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $name_uz = $_POST['name_uz'];
    $name_ru = $_POST['name_ru'];
    $qty = $_POST['qty'];
    $price = $_POST['price'];

    $stmt = $db->prepare("INSERT INTO inventory (name_uz, name_ru, stock_quantity, price) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name_uz, $name_ru, $qty, $price]);
    header("Location: inventory.php");
    exit;
}

// Mahsulotni o'chirish
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM inventory WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: inventory.php");
    exit;
}

$products = $db->query("SELECT * FROM inventory ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="<?= Lang::$current ?>">
<head>
    <meta charset="UTF-8">
    <title><?= Lang::t('inventory') ?> | Hisobot.uz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar { min-width: 250px; background: #2c3e50; min-height: 100vh; color: white; position: fixed; }
        .main-content { margin-left: 250px; width: calc(100% - 250px); }
        .sidebar a { color: #bdc3c7; text-decoration: none; padding: 15px 20px; display: block; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: white; border-left: 4px solid #3498db; }
    </style>
</head>
<body class="bg-light">

<div class="d-flex">
    <div class="sidebar shadow">
        <div class="p-4 text-center"><h4 class="fw-bold">HISOBOT.UZ</h4><hr></div>
        <a href="dashboard.php"><i class="fas fa-chart-line me-2"></i> <?= Lang::t('dashboard') ?></a>
        <a href="inventory.php" class="active"><i class="fas fa-boxes me-2"></i> <?= Lang::t('inventory') ?></a>
        <a href="finance.php"><i class="fas fa-wallet me-2"></i> <?= Lang::t('finance') ?></a>
        <a href="logout.php" class="text-danger mt-5"><i class="fas fa-sign-out-alt me-2"></i> <?= Lang::t('logout') ?></a>
    </div>

    <div class="main-content">
        <nav class="navbar navbar-white bg-white shadow-sm mb-4 p-3 px-4">
            <h5 class="m-0 fw-bold"><?= Lang::t('inventory') ?></h5>
            <button class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="fas fa-plus me-1"></i> <?= Lang::t('add_product') ?>
            </button>
        </nav>

        <div class="container-fluid px-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>ID</th>
                                <th><?= Lang::t('product_name') ?></th>
                                <th><?= Lang::t('qty') ?></th>
                                <th><?= Lang::t('price') ?></th>
                                <th class="text-end"><?= Lang::t('actions') ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($products as $p): ?>
                            <tr>
                                <td>#<?= $p['id'] ?></td>
                                <td><?= Lang::db($p, 'name') ?></td>
                                <td><span class="badge bg-info"><?= $p['stock_quantity'] ?></span></td>
                                <td><?= number_format($p['price'], 0, '.', ' ') ?> UZS</td>
                                <td class="text-end">
                                    <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Ishonchingiz komilmi?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="" method="POST" class="modal-content">
            <div class="modal-header"><h5><?= Lang::t('add_product') ?></h5></div>
            <div class="modal-body">
                <div class="mb-3"><label>Nomi (UZ)</label><input type="text" name="name_uz" class="form-control" required></div>
                <div class="mb-3"><label>Название (RU)</label><input type="text" name="name_ru" class="form-control" required></div>
                <div class="row">
                    <div class="col-6 mb-3"><label><?= Lang::t('qty') ?></label><input type="number" name="qty" class="form-control" required></div>
                    <div class="col-6 mb-3"><label><?= Lang::t('price') ?></label><input type="number" name="price" class="form-control" required></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
                <button type="submit" name="add_product" class="btn btn-primary">Saqlash</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>