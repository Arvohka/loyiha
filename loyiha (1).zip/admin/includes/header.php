<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../core/Database.php';
require_once '../core/Lang.php';
require_once '../core/Auth.php';

Auth::check();
Lang::init();

$db = (new Database())->getConnection();
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="<?= Lang::$current ?>">
<head>
    <meta charset="UTF-8">
    <title><?= Lang::t('admin_panel') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --sidebar-bg: #2c3e50; }
        body { background: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
        .sidebar { width: 260px; background: var(--sidebar-bg); min-height: 100vh; position: fixed; color: #ecf0f1; }
        .main { margin-left: 260px; padding: 25px; }
        .sidebar a { color: #bdc3c7; text-decoration: none; padding: 15px 20px; display: block; border-left: 4px solid transparent; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: white; border-left-color: #3498db; }
        .card-stat { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 text-center border-bottom border-secondary">
        <h4 class="fw-bold m-0 text-white">HISOBOT.UZ</h4>
        <small class="text-info"><?= Lang::t('system_admin') ?></small>
    </div>
    <div class="mt-3">
        <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-tachometer-alt me-2"></i> <?= Lang::t('dashboard') ?></a>
        <a href="tariffs.php"><i class="fas fa-tags me-2"></i> <?= Lang::t('tariffs_management') ?></a>
        <a href="barcodes.php" class="<?= $current_page == 'barcodes.php' ? 'active' : '' ?>"><i class="fas fa-barcode me-2"></i> <?= Lang::t('barcode_registry') ?></a>
        <a href="products.php" class="<?= $current_page == 'products.php' ? 'active' : '' ?>"><i class="fas fa-boxes me-2"></i> <?= Lang::t('products') ?></a>
        <a href="categories.php" class="<?= $current_page == 'categories.php' ? 'active' : '' ?>"><i class="fas fa-list me-2"></i> <?= Lang::t('categories') ?></a>
        <a href="users.php" class="<?= $current_page == 'users.php' ? 'active' : '' ?>"><i class="fas fa-users me-2"></i> <?= Lang::t('users_manage') ?></a>
        <a href="settings.php" class="<?= $current_page == 'settings.php' ? 'active' : '' ?>"><i class="fas fa-cogs me-2"></i> <?= Lang::t('settings') ?></a>
        <a href="../logout.php" class="text-danger mt-5"><i class="fas fa-sign-out-alt me-2"></i> <?= Lang::t('logout') ?></a>
    </div>
</div>

<div class="main">
    <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 rounded shadow-sm">
        <h5 class="m-0 fw-bold"><?= Lang::t('admin_dashboard') ?></h5>
        <div class="d-flex gap-2 align-items-center">
            <div class="btn-group me-3">
                <a href="?lang=uz" class="btn btn-sm <?= Lang::$current == 'uz' ? 'btn-primary' : 'btn-outline-primary' ?>">UZ</a>
                <a href="?lang=ru" class="btn btn-sm <?= Lang::$current == 'ru' ? 'btn-primary' : 'btn-outline-primary' ?>">RU</a>
            </div>
            <span class="badge bg-light text-dark border p-2"><i class="fas fa-user-shield me-1"></i> <?= $_SESSION['fullname'] ?></span>
        </div>
    </div>