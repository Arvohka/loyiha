<?php
include 'includes/header.php';

// AJAX so'rovlar
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    try {
        if ($_POST['action'] == 'add') {
            $stmt = $db->prepare("INSERT INTO products (category_id, name, sku, price, quantity, unit) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['category_id'], $_POST['name'], $_POST['sku'], $_POST['price'], $_POST['quantity'], $_POST['unit']]);
            echo json_encode(['status' => 'success']);
        }
        if ($_POST['action'] == 'delete') {
            $db->prepare("DELETE FROM products WHERE id = ?")->execute([$_POST['id']]);
            echo json_encode(['status' => 'success']);
        }
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}

// SQL so'rovni xatolikka tekshirish
try {
    $products = $db->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $products = $db->query("SELECT p.*, c.category_name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC")->fetchAll(PDO::FETCH_ASSOC);
}

$categories = $db->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 rounded shadow-sm border">
    <h5 class="m-0 fw-bold"><?= Lang::t('products') ?></h5>
    <button class="btn btn-primary btn-sm px-3" data-bs-toggle="modal" data-bs-target="#addModal">
        <i class="fas fa-plus me-1"></i> <?= Lang::t('add_product') ?>
    </button>
</div>

<div class="card p-4">
    <div class="table-responsive">
        <table class="table align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th class="text-start"><?= Lang::t('product_name') ?></th>
                    <th><?= Lang::t('sku') ?></th>
                    <th><?= Lang::t('price') ?></th>
                    <th><?= Lang::t('quantity') ?></th>
                    <th><?= Lang::t('edit') ?></th>
                    <th><?= Lang::t('delete') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($products as $p): ?>
                <tr id="row_<?= $p['id'] ?>">
                    <td>#<?= $p['id'] ?></td>
                    <td class="text-start">
                        <div class="fw-bold"><?= htmlspecialchars($p['name']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($p['cat_name'] ?? '---') ?></small>
                    </td>
                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($p['sku']) ?></span></td>
                    <td class="text-primary fw-bold"><?= number_format($p['price'], 0, '.', ' ') ?></td>
                    <td><span class="badge bg-success"><?= $p['quantity'] ?> <?= $p['unit'] ?></span></td>
                    <td><button class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></button></td>
                    <td><button class="btn btn-sm btn-danger delete-btn" data-id="<?= $p['id'] ?>"><i class="fas fa-trash"></i></button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form class="modal-content" id="addForm">
            <input type="hidden" name="action" value="add">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold"><?= Lang::t('add_product') ?></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><?= Lang::t('product_name') ?></label>
                        <input type="text" name="name" class="form-control" placeholder="<?= Lang::t('enter_name') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><?= Lang::t('categories') ?></label>
                        <select name="category_id" class="form-select">
                            <?php foreach($categories as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name'] ?? ($c['category_name'] ?? '')) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4"><label class="form-label small fw-bold"><?= Lang::t('sku') ?></label><input type="text" name="sku" class="form-control"></div>
                    <div class="col-md-4"><label class="form-label small fw-bold"><?= Lang::t('price') ?></label><input type="number" name="price" class="form-control" required></div>
                    <div class="col-md-2"><label class="form-label small fw-bold"><?= Lang::t('quantity') ?></label><input type="number" name="quantity" class="form-control" value="0"></div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold"><?= Lang::t('unit') ?></label>
                        <select name="unit" class="form-select">
                            <option value="dona"><?= Lang::t('unit_dona') ?></option>
                            <option value="kg"><?= Lang::t('unit_kg') ?></option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" class="btn btn-primary btn-sm px-4"><?= Lang::t('save') ?></button>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#addForm').on('submit', function(e) {
        e.preventDefault();
        $.post('products.php', $(this).serialize(), function(res) {
            if(res.status === 'success') location.reload();
        });
    });

    $('.delete-btn').on('click', function() {
        if(confirm('<?= Lang::t('confirm_delete') ?>')) {
            let id = $(this).data('id');
            $.post('products.php', {action: 'delete', id: id}, function(res) {
                if(res.status === 'success') $('#row_' + id).fadeOut();
            });
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>