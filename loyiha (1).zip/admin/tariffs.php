<?php
include 'includes/header.php';

// Yangi tarif saqlash
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_tariff'])) {
    $sql = "INSERT INTO tariff_plans (name, duration_months, price, old_price, cashier_limit, warehouseman_limit, product_limit, has_click, has_payme, has_debt_book, has_cash, has_terminal, debt_log_days, module_name) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'magazin')";
    $stmt = $db->prepare($sql);
    $stmt->execute([
        $_POST['name'], $_POST['duration_months'], $_POST['price'], $_POST['old_price'],
        $_POST['cashier_limit'], $_POST['warehouseman_limit'], $_POST['product_limit'],
        isset($_POST['has_click']) ? 1 : 0,
        isset($_POST['has_payme']) ? 1 : 0,
        isset($_POST['has_debt_book']) ? 1 : 0,
        isset($_POST['has_cash']) ? 1 : 0,
        isset($_POST['has_terminal']) ? 1 : 0,
        $_POST['debt_log_days']
    ]);
    echo "<script>location.href='tariffs.php';</script>";
}

if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM tariff_plans WHERE id = ?")->execute([$_GET['delete']]);
    echo "<script>location.href='tariffs.php';</script>";
}

$tariffs = $db->query("SELECT * FROM tariff_plans ORDER BY price ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 rounded shadow-sm border">
    <h5 class="m-0 fw-bold"><i class="fas fa-layer-group me-2 text-primary"></i><?= Lang::t('tariffs_management') ?></h5>
    <button class="btn btn-primary btn-sm px-4" data-bs-toggle="modal" data-bs-target="#tariffModal">
        <i class="fas fa-plus me-1"></i> <?= Lang::t('add_new_tariff') ?>
    </button>
</div>

<div class="row">
    <?php foreach($tariffs as $t): ?>
    <div class="col-md-4 mb-4">
        <div class="card h-100 shadow-sm border-0 position-relative" style="border-radius: 15px;">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="fw-bold text-dark m-0"><?= htmlspecialchars($t['name']) ?></h5>
                    <a href="?delete=<?= $t['id'] ?>" class="btn btn-link text-danger p-0" onclick="return confirm('<?= Lang::t('confirm_delete') ?>')"><i class="fas fa-trash-alt"></i></a>
                </div>

                <div class="mb-3">
                    <?php if($t['old_price'] > $t['price']): ?>
                        <span class="badge bg-danger mb-1">-<?= round((($t['old_price']-$t['price'])/$t['old_price'])*100) ?>%</span><br>
                        <del class="text-muted small"><?= number_format($t['old_price'], 0, '.', ' ') ?> <?= Lang::t('currency') ?></del>
                    <?php endif; ?>
                    <h3 class="text-primary fw-bold mb-0"><?= number_format($t['price'], 0, '.', ' ') ?> <small class="fs-6 text-muted">/ <?= $t['duration_months'] ?> <?= Lang::t('month') ?></small></h3>
                </div>

                <ul class="list-unstyled small border-top pt-3">
                    <li class="mb-2"><i class="fas fa-users-cog text-primary me-2"></i> <?= Lang::t('cashiers') ?>: <b><?= $t['cashier_limit'] ?></b></li>
                    <li class="mb-2"><i class="fas fa-warehouse text-primary me-2"></i> <?= Lang::t('warehousers') ?>: <b><?= $t['warehouseman_limit'] ?></b></li>
                    <li class="mb-2"><i class="fas fa-box text-primary me-2"></i> <?= Lang::t('products_limit') ?>: <b><?= $t['product_limit'] ?></b></li>
                    <li class="mb-2 border-top pt-2 mt-2"><b><?= Lang::t('payment_methods') ?>:</b></li>
                    <li class="mb-1"><i class="fas fa-check <?= $t['has_cash'] ? 'text-success' : 'text-light' ?> me-2"></i> <?= Lang::t('cash_payment') ?></li>
                    <li class="mb-1"><i class="fas fa-check <?= $t['has_terminal'] ? 'text-success' : 'text-light' ?> me-2"></i> <?= Lang::t('terminal_payment') ?></li>
                    <li class="mb-2 border-top pt-2 mt-2"><b><?= Lang::t('modules') ?>:</b></li>
                    <li class="mb-1 text-<?= $t['has_debt_book'] ? 'success' : 'muted' ?>"><i class="fas fa-book me-2"></i> <?= Lang::t('debt_book') ?> (<?= $t['debt_log_days'] ?> <?= Lang::t('days') ?>)</li>
                    <li class="mb-1 text-<?= $t['has_click'] ? 'success' : 'muted' ?>"><i class="fas fa-mouse-pointer me-2"></i> Click.uz</li>
                    <li class="mb-1 text-<?= $t['has_payme'] ? 'success' : 'muted' ?>"><i class="fas fa-credit-card me-2"></i> Payme</li>
                </ul>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<div class="modal fade" id="tariffModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form class="modal-content" method="POST">
            <div class="modal-header">
                <h6 class="modal-title fw-bold"><?= Lang::t('tariff_editor') ?></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><?= Lang::t('tariff_name') ?></label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold"><?= Lang::t('duration') ?> (<?= Lang::t('month') ?>)</label>
                        <input type="number" name="duration_months" class="form-control" value="1" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold"><?= Lang::t('products_limit') ?></label>
                        <input type="number" name="product_limit" class="form-control" value="1000" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><?= Lang::t('price') ?></label>
                        <input type="number" name="price" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><?= Lang::t('old_price') ?></label>
                        <input type="number" name="old_price" class="form-control" value="0">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold"><?= Lang::t('cashiers_count') ?></label>
                        <input type="number" name="cashier_limit" class="form-control" value="1" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold"><?= Lang::t('warehousers_count') ?></label>
                        <input type="number" name="warehouseman_limit" class="form-control" value="1" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold"><?= Lang::t('debt_history_days') ?></label>
                        <input type="number" name="debt_log_days" class="form-control" value="30" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-bold"><?= Lang::t('additional_features') ?>:</label>
                        <div class="p-3 border rounded bg-light">
                            <div class="row">
                                <div class="col-md-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="has_cash" checked><label class="form-check-label"><?= Lang::t('cash') ?></label></div></div>
                                <div class="col-md-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="has_terminal" checked><label class="form-check-label"><?= Lang::t('terminal') ?></label></div></div>
                                <div class="col-md-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="has_debt_book"><label class="form-check-label"><?= Lang::t('debt_book') ?></label></div></div>
                                <div class="col-md-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="has_click"><label class="form-check-label">Click.uz</label></div></div>
                                <div class="col-md-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="has_payme"><label class="form-check-label">Payme</label></div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="save_tariff" class="btn btn-primary w-100"><?= Lang::t('save') ?></button>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>