<?php 
include 'includes/header.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $upload_dir = '../uploads/products/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

    if ($_POST['action'] === 'add' || $_POST['action'] === 'edit') {
        $image_name = $_POST['current_image'] ?? null;
        if (!empty($_POST['external_image_url']) && empty($_FILES['image']['name'])) {
            $image_content = @file_get_contents($_POST['external_image_url']);
            if($image_content) {
                $image_name = time() . '_' . $_POST['barcode'] . '.jpg';
                file_put_contents($upload_dir . $image_name, $image_content);
            }
        }
        if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_name = time() . '_' . $_POST['barcode'] . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $image_name);
        }

        $full_name = $_POST['product_name'] . (isset($_POST['size']) && $_POST['size'] ? ' ' . $_POST['size'] : '');
        
        if ($_POST['action'] === 'add') {
            $stmt = $db->prepare("INSERT INTO barcode_base (barcode, product_name, image, category, unit) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['barcode'], $full_name, $image_name, $_POST['category'], $_POST['unit']]);
        } else {
            $stmt = $db->prepare("UPDATE barcode_base SET barcode = ?, product_name = ?, image = ?, category = ?, unit = ? WHERE id = ?");
            $stmt->execute([$_POST['barcode'], $full_name, $image_name, $_POST['category'], $_POST['unit'], $_POST['id']]);
        }
        header("Location: barcodes.php"); exit;
    }
    
    if ($_POST['action'] === 'delete') {
        $stmt = $db->prepare("DELETE FROM barcode_base WHERE id = ?");
        $res = $stmt->execute([$_POST['id']]);
        header('Content-Type: application/json');
        echo json_encode(['status' => $res ? 'success' : 'error']); exit;
    }
}
?>

<div class="container-fluid">
    <div class="card border-0 shadow-sm p-3 mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0 text-primary"><i class="fas fa-boxes me-2"></i> <?= Lang::t('barcode_registry') ?></h5>
            <button class="btn btn-primary btn-sm px-4 shadow-sm" onclick="openAddModal()"><i class="fas fa-plus me-1"></i> <?= Lang::t('add_new') ?></button>
        </div>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 text-center">
                <thead class="bg-light text-secondary small text-uppercase">
                    <tr>
                        <th><?= Lang::t('image') ?></th>
                        <th><?= Lang::t('barcode') ?></th>
                        <th><?= Lang::t('product_name') ?></th>
                        <th><?= Lang::t('category') ?></th>
                        <th class="text-end pe-4"><?= Lang::t('actions') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $db->query("SELECT * FROM barcode_base ORDER BY id DESC");
                    while($row = $stmt->fetch(PDO::FETCH_ASSOC)): 
                        $rowData = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                    ?>
                    <tr id="row-<?= $row['id'] ?>">
                        <td><img src="../uploads/products/<?= $row['image'] ?: 'no-image.png' ?>" class="rounded border" style="width: 45px; height: 45px; object-fit: cover;"></td>
                        <td>
                            <div class="d-flex flex-column align-items-center">
                                <img src="https://barcodeapi.org/api/128/<?= $row['barcode'] ?>" style="height: 30px; max-width: 120px;">
                                <small class="fw-bold text-danger mt-1"><?= $row['barcode'] ?></small>
                            </div>
                        </td>
                        <td class="fw-bold text-start"><?= htmlspecialchars($row['product_name']) ?></td>
                        <td><?= htmlspecialchars($row['category']) ?></td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm btn-outline-primary border-0" onclick='openEditModal(this)' data-json='<?= $rowData ?>'><i class="fas fa-edit"></i></button>
                            <button class="btn btn-sm btn-outline-danger border-0" onclick="deleteItem(<?= $row['id'] ?>)"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="barcodeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h6 class="modal-title fw-bold" id="mTitle"></h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="bForm">
                <input type="hidden" name="action" id="fAction">
                <input type="hidden" name="id" id="fId">
                <input type="hidden" name="current_image" id="fImg">
                <input type="hidden" name="external_image_url" id="extImgUrl">
                <div class="modal-body p-4">
                    <div id="pLoader" class="text-primary small mb-2 d-none"><i class="fas fa-spinner fa-spin"></i> <?= Lang::t('searching') ?></div>
                    
                    <div class="row mb-3">
                        <div class="col-4 text-center">
                            <img id="prev" src="../uploads/products/no-image.png" class="rounded border shadow-sm w-100" style="height: 100px; object-fit: cover;">
                        </div>
                        <div class="col-8">
                            <label class="small fw-bold"><?= Lang::t('product_name') ?></label>
                            <div class="input-group">
                                <input type="text" name="product_name" id="iN" class="form-control" required>
                                <button class="btn btn-dark" type="button" onclick="findRealBarcode(document.getElementById('iN').value)"><i class="fas fa-search"></i></button>
                            </div>
                            <input type="file" name="image" class="form-control form-control-sm mt-2" accept="image/*" onchange="document.getElementById('prev').src = window.URL.createObjectURL(this.files[0])">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="small fw-bold"><?= Lang::t('product_type') ?></label>
                        <select id="pType" class="form-select bg-light" onchange="toggleFields(this.value)">
                            <option value="other"><?= Lang::t('type_other') ?></option>
                            <option value="drink"><?= Lang::t('type_drink') ?></option>
                            <option value="weight"><?= Lang::t('type_weight') ?></option>
                        </select>
                    </div>

                    <div id="sizeSection" class="mb-3 d-none text-primary fw-bold p-2 border rounded">
                        <label class="small d-block mb-1"><?= Lang::t('select_size') ?>:</label>
                        <select name="size" id="iSize" class="form-select border-primary"></select>
                    </div>

                    <div class="row">
                        <div class="col-7 mb-3">
                            <label class="small fw-bold text-danger"><?= Lang::t('barcode') ?></label>
                            <input type="text" name="barcode" id="iB" class="form-control fw-bold border-danger" required>
                        </div>
                        <div class="col-5 mb-3">
                            <label class="small fw-bold"><?= Lang::t('unit') ?></label>
                            <select name="unit" id="iU" class="form-select">
                                <option value="ta"><?= Lang::t('unit_pcs') ?></option>
                                <option value="kg"><?= Lang::t('unit_kg') ?></option>
                                <option value="litr"><?= Lang::t('unit_litr') ?></option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="small fw-bold"><?= Lang::t('category') ?></label>
                        <input type="text" name="category" id="iC" class="form-control">
                    </div>
                </div>
                <div class="modal-footer border-0 px-4 pb-4">
                    <button type="submit" class="btn btn-primary w-100 py-2 shadow-sm fw-bold"><?= Lang::t('save_to_base') ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let bModal;
document.addEventListener('DOMContentLoaded', () => { bModal = new bootstrap.Modal(document.getElementById('barcodeModal')); });

function toggleFields(type) {
    const section = document.getElementById('sizeSection');
    const select = document.getElementById('iSize');
    const unit = document.getElementById('iU');
    section.classList.add('d-none');
    select.innerHTML = '';

    if (type === 'drink') {
        section.classList.remove('d-none');
        ['0.5L', '1L', '1.5L', '2L', '2.5L'].forEach(s => select.add(new Option(s, s)));
        unit.value = 'litr';
    } else if (type === 'weight') {
        section.classList.remove('d-none');
        ['250g', '500g', '1kg', '5kg', '10kg', '25kg', '50kg'].forEach(s => select.add(new Option(s, s)));
        unit.value = 'kg';
    }
}

async function findRealBarcode(name) {
    if (name.length < 3) return;
    document.getElementById('pLoader').classList.remove('d-none');
    try {
        const res = await fetch(`https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(name)}&search_simple=1&action=process&json=1`);
        const data = await res.json();
        if (data.products && data.products.length > 0) {
            const p = data.products[0];
            document.getElementById('iB').value = p.code || '';
            document.getElementById('iC').value = p.categories ? p.categories.split(',')[0] : '';
            if (p.image_url) { document.getElementById('prev').src = p.image_url; document.getElementById('extImgUrl').value = p.image_url; }
        } else { alert("<?= Lang::t('not_found') ?>"); }
    } catch (e) { alert("<?= Lang::t('error_conn') ?>"); }
    document.getElementById('pLoader').classList.add('d-none');
}

function openAddModal() {
    document.getElementById('bForm').reset();
    document.getElementById('fAction').value = 'add';
    document.getElementById('mTitle').innerText = "<?= Lang::t('add_new') ?>";
    document.getElementById('prev').src = '../uploads/products/no-image.png';
    document.getElementById('sizeSection').classList.add('d-none');
    bModal.show();
}

function openEditModal(btn) {
    const data = JSON.parse(btn.getAttribute('data-json'));
    document.getElementById('fAction').value = 'edit';
    document.getElementById('mTitle').innerText = "<?= Lang::t('edit') ?>";
    document.getElementById('fId').value = data.id;
    document.getElementById('iB').value = data.barcode;
    document.getElementById('iN').value = data.product_name;
    document.getElementById('iC').value = data.category;
    document.getElementById('iU').value = data.unit;
    document.getElementById('fImg').value = data.image;
    document.getElementById('prev').src = data.image ? '../uploads/products/' + data.image : '../uploads/products/no-image.png';
    bModal.show();
}

function deleteItem(id) {
    if(confirm("<?= Lang::t('confirm_delete') ?>")) {
        const fd = new FormData(); fd.append('action', 'delete'); fd.append('id', id);
        fetch('barcodes.php', { method: 'POST', body: fd }).then(r => r.json()).then(d => { if(d.status === 'success') document.getElementById('row-' + id).remove(); });
    }
}
</script>

<?php include 'includes/footer.php'; ?>