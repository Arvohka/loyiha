<?php
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $n_uz = trim($_POST['name_uz']);
    $n_ru = trim($_POST['name_ru']);
    
    $stmt = $db->prepare("INSERT INTO categories (name, name_uz, name_ru) VALUES (?, ?, ?)");
    $stmt->execute([$n_uz, $n_uz, $n_ru]);
}

header("Location: categories.php");
exit;