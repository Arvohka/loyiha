<?php
include 'includes/header.php';

// Tizim statistikasi
$total_users = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_reports = $db->query("SELECT COUNT(*) FROM reports")->fetchColumn();
$recent_users = $db->query("SELECT * FROM users ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="row g-4 mb-5">
    <div class="col-md-4">
        <div class="card card-stat p-4 bg-white border-start border-primary border-5">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-muted small fw-bold text-uppercase"><?= Lang::t('total_users') ?></h6>
                    <h2 class="fw-bold m-0"><?= $total_users ?></h2>
                </div>
                <i class="fas fa-users fa-2x text-primary opacity-25"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-stat p-4 bg-white border-start border-warning border-5">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-muted small fw-bold text-uppercase"><?= Lang::t('total_records') ?></h6>
                    <h2 class="fw-bold m-0"><?= $total_reports ?></h2>
                </div>
                <i class="fas fa-file-invoice fa-2x text-warning opacity-25"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-stat p-4 bg-white border-start border-info border-5">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="text-muted small fw-bold text-uppercase"><?= Lang::t('system_status') ?></h6>
                    <h2 class="fw-bold m-0 text-success">Active</h2>
                </div>
                <i class="fas fa-check-circle fa-2x text-success opacity-25"></i>
            </div>
        </div>
    </div>
</div>

<div class="card card-stat p-4">
    <h6 class="fw-bold mb-4"><?= Lang::t('recent_registrations') ?></h6>
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th><?= Lang::t('fullname') ?></th>
                    <th><?= Lang::t('username') ?></th>
                    <th><?= Lang::t('role') ?></th>
                    <th><?= Lang::t('date') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($recent_users as $u): ?>
                <tr>
                    <td>#<?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['fullname']) ?></td>
                    <td><span class="badge bg-secondary"><?= htmlspecialchars($u['username']) ?></span></td>
                    <td><?= htmlspecialchars($u['role']) ?></td>
                    <td class="text-muted small"><?= $u['created_at'] ?? '-' ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>