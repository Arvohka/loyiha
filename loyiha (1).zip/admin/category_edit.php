<?php
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $n_uz = trim($_POST['name_uz']);
    $n_ru = trim($_POST['name_ru']);
    
    // name_uz ni asosiy 'name' ustuniga ham yozamiz
    $stmt = $db->prepare("UPDATE categories SET name = ?, name_uz = ?, name_ru = ? WHERE id = ?");
    $stmt->execute([$n_uz, $n_uz, $n_ru, $id]);
}

header("Location: categories.php");
exit;