<?php
include 'includes/header.php';

if (isset($_GET['delete']) && is_numeric($_GET['delete']) && $_GET['delete'] != $_SESSION['user_id']) {
    $db->prepare("DELETE FROM users WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: users.php"); exit;
}

if (isset($_GET['toggle_status']) && is_numeric($_GET['toggle_status']) && $_GET['toggle_status'] != $_SESSION['user_id']) {
    $db->prepare("UPDATE users SET status = IF(status='active', 'blocked', 'active') WHERE id = ?")->execute([$_GET['toggle_status']]);
    header("Location: users.php"); exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_user'])) {
    $stmt = $db->prepare("UPDATE users SET fullname = ?, role = ? WHERE id = ?");
    $stmt->execute([$_POST['fullname'], $_POST['role'], $_POST['user_id']]);
    header("Location: users.php"); exit;
}

$users = $db->query("SELECT * FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 rounded shadow-sm border">
    <h5 class="m-0 fw-bold"><?= Lang::t('users_manage') ?></h5>
</div>

<div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 12px;">
    <div class="table-responsive">
        <table class="table align-middle text-center">
            <thead class="table-light text-muted small">
                <tr>
                    <th class="text-start">ID</th>
                    <th class="text-start"><?= Lang::t('fullname') ?></th>
                    <th><?= Lang::t('login') ?></th>
                    <th><?= Lang::t('role') ?></th>
                    <th><?= Lang::t('status') ?></th>
                    <th><?= Lang::t('date') ?></th>
                    <th><?= Lang::t('edit') ?></th>
                    <th><?= Lang::t('block') ?></th>
                    <th><?= Lang::t('delete') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $u): ?>
                <tr>
                    <td class="text-start text-muted small">#<?= $u['id'] ?></td>
                    <td class="text-start fw-bold"><?= htmlspecialchars($u['fullname']) ?></td>
                    <td><span class="badge bg-info text-dark rounded-pill px-3"><?= htmlspecialchars($u['username']) ?></span></td>
                    <td><span class="badge bg-danger rounded-1 px-2"><?= strtoupper($u['role']) ?></span></td>
                    <td>
                        <span class="badge bg-success rounded-pill px-3"><?= $u['status'] ?? 'active' ?></span>
                        <?php if($u['id'] == $_SESSION['user_id']): ?>
                            <span class="badge-online d-block mt-1 small text-muted" style="font-size: 10px; font-weight: 600;"><?= Lang::t('online_you') ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted small"><?= $u['created_at'] ?></td>
                    
                    <td>
                        <button class="btn btn-sm btn-primary" style="width: 32px; height: 32px;" data-bs-toggle="modal" data-bs-target="#editModal<?= $u['id'] ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                    </td>

                    <td>
                        <?php if($u['id'] != $_SESSION['user_id']): ?>
                            <a href="?toggle_status=<?= $u['id'] ?>" class="btn btn-sm <?= ($u['status'] ?? 'active') == 'active' ? 'btn-warning' : 'btn-success' ?>" style="width: 32px; height: 32px;">
                                <i class="fas <?= ($u['status'] ?? 'active') == 'active' ? 'fa-ban' : 'fa-check' ?>"></i>
                            </a>
                        <?php else: ?>
                            <button class="btn btn-sm btn-secondary opacity-50" style="width: 32px; height: 32px;" disabled><i class="fas fa-ban"></i></button>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if($u['id'] != $_SESSION['user_id']): ?>
                            <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-danger" style="width: 32px; height: 32px;" onclick="return confirm('<?= Lang::t('confirm_delete') ?>')">
                                <i class="fas fa-trash"></i>
                            </a>
                        <?php else: ?>
                            <button class="btn btn-sm btn-secondary opacity-50" style="width: 32px; height: 32px;" disabled><i class="fas fa-trash"></i></button>
                        <?php endif; ?>
                    </td>
                </tr>

                <div class="modal fade" id="editModal<?= $u['id'] ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form class="modal-content" method="POST">
                            <div class="modal-header">
                                <h6 class="modal-title fw-bold"><?= Lang::t('edit_user_data') ?></h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body text-start">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <div class="mb-3">
                                    <label class="form-label small fw-bold"><?= Lang::t('fullname') ?></label>
                                    <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($u['fullname']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-bold"><?= Lang::t('role') ?></label>
                                    <select name="role" class="form-select" <?= $u['id'] == $_SESSION['user_id'] ? 'disabled' : '' ?>>
                                        <option value="admin" <?= $u['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                                        <option value="user" <?= $u['role'] == 'user' ? 'selected' : '' ?>>User</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal"><?= Lang::t('close') ?></button>
                                <button type="submit" name="edit_user" class="btn btn-sm btn-primary px-4"><?= Lang::t('save') ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>