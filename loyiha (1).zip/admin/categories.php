<?php
include 'includes/header.php';
$categories = $db->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$current_lang = $_SESSION['lang'] ?? 'uz';
$name_field = ($current_lang == 'ru') ? 'name_ru' : 'name_uz';
?>

<div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 rounded shadow-sm border">
    <h5 class="m-0 fw-bold"><?= Lang::t('categories') ?></h5>
    <button type="button" class="btn btn-primary btn-sm px-4" data-bs-toggle="modal" data-bs-target="#catModal" onclick="prepareAdd()">
        <i class="fas fa-plus me-1"></i> <?= Lang::t('add_category') ?>
    </button>
</div>

<div class="card p-0 bg-white shadow-sm border-0" style="border-radius: 12px; overflow: hidden;">
    <table class="table align-middle mb-0">
        <thead class="table-light small text-muted text-uppercase">
            <tr>
                <th class="ps-4">ID</th>
                <th><?= Lang::t('name') ?></th>
                <th class="text-end pe-4"><?= Lang::t('action') ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($categories as $c): ?>
            <tr>
                <td class="ps-4">#<?= $c['id'] ?></td>
                <td class="fw-bold"><?= htmlspecialchars($c[$name_field] ?: $c['name_uz']) ?></td>
                <td class="text-end pe-4 text-nowrap">
                    <button type="button" class="btn btn-sm text-primary border-0" 
                            data-bs-toggle="modal" data-bs-target="#catModal"
                            onclick="prepareEdit('<?= $c['id'] ?>', '<?= addslashes($c['name_uz']) ?>', '<?= addslashes($c['name_ru']) ?>')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <a href="category_delete.php?id=<?= $c['id'] ?>" class="btn btn-sm text-danger border-0" onclick="return confirm('<?= Lang::t('confirm_delete') ?>')">
                        <i class="fas fa-trash"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="modal fade" id="catModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow-lg" method="POST" id="catForm">
            <input type="hidden" name="id" id="mId">
            <div class="modal-header bg-primary text-white border-0">
                <h6 class="modal-title fw-bold" id="mTitle"></h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('name_uz') ?></label>
                    <input type="text" name="name_uz" id="nUz" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('name_ru') ?></label>
                    <input type="text" name="name_ru" id="nRu" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold shadow-sm"><?= Lang::t('save') ?></button>
            </div>
        </form>
    </div>
</div>

<script>
function prepareAdd() {
    document.getElementById('catForm').action = 'category_add.php';
    document.getElementById('catForm').reset();
    document.getElementById('mId').value = '';
    document.getElementById('mTitle').innerText = '<?= Lang::t('add_category') ?>';
}

function prepareEdit(id, uz, ru) {
    document.getElementById('catForm').action = 'category_edit.php';
    document.getElementById('mId').value = id;
    document.getElementById('nUz').value = uz;
    document.getElementById('nRu').value = ru;
    document.getElementById('mTitle').innerText = '<?= Lang::t('edit_category') ?>';
}
</script>
<?php include 'includes/footer.php'; ?>