<?php
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$success = false;
$error = false;

// Tizim sozlamalarini saqlash
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_system'])) {
    $stmt = $db->prepare("UPDATE settings SET site_name = ?, site_domain = ?, meta_description = ?, meta_keywords = ? WHERE id = 1");
    $stmt->execute([$_POST['site_name'], $_POST['site_domain'], $_POST['meta_description'], $_POST['meta_keywords']]);
    $success = Lang::t('settings_updated');
}

// Parolni o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (password_verify($_POST['current_password'], $user['password'])) {
        if ($_POST['new_password'] === $_POST['confirm_password']) {
            $hashed = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed, $user_id]);
            $success = Lang::t('password_updated');
        } else {
            $error = Lang::t('passwords_not_match');
        }
    } else {
        $error = Lang::t('current_password_wrong');
    }
}

// Ma'lumotlarni olish
$settings = $db->query("SELECT * FROM settings WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
$user_data = $db->prepare("SELECT * FROM users WHERE id = ?");
$user_data->execute([$user_id]);
$me = $user_data->fetch(PDO::FETCH_ASSOC);
?>

<?php if($success): ?> <div class="alert alert-success"><?= $success ?></div> <?php endif; ?>
<?php if($error): ?> <div class="alert alert-danger"><?= $error ?></div> <?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card card-stat p-4 bg-white mb-4">
            <h6 class="fw-bold mb-4 border-bottom pb-2"><i class="fas fa-globe me-2"></i> <?= Lang::t('system_params') ?></h6>
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold"><?= Lang::t('site_name') ?></label>
                        <input type="text" name="site_name" class="form-control" value="<?= htmlspecialchars($settings['site_name']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold"><?= Lang::t('domain_url') ?></label>
                        <input type="text" name="site_domain" class="form-control" value="<?= htmlspecialchars($settings['site_domain']) ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('meta_desc') ?></label>
                    <textarea name="meta_description" class="form-control" rows="2"><?= htmlspecialchars($settings['meta_description']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><?= Lang::t('meta_keys') ?></label>
                    <textarea name="meta_keywords" class="form-control" rows="2"><?= htmlspecialchars($settings['meta_keywords']) ?></textarea>
                </div>
                <button type="submit" name="update_system" class="btn btn-primary px-4"><?= Lang::t('save') ?></button>
            </form>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-stat p-4 bg-white mb-4 text-center border-0 shadow-sm">
            <i class="fas fa-user-shield fa-3x text-primary mb-3"></i>
            <h6 class="fw-bold m-0"><?= htmlspecialchars($me['fullname']) ?></h6>
            <span class="badge bg-light text-primary border mt-2"><?= strtoupper($me['role']) ?></span>
        </div>
        
        <div class="card card-stat p-4 bg-white border-0 shadow-sm">
            <h6 class="fw-bold mb-3 small"><?= Lang::t('security') ?></h6>
            <form method="POST">
                <div class="mb-2">
                    <input type="password" name="current_password" class="form-control form-control-sm" placeholder="<?= Lang::t('current_password') ?>" required>
                </div>
                <div class="mb-2">
                    <input type="password" name="new_password" class="form-control form-control-sm" placeholder="<?= Lang::t('new_password') ?>" required>
                </div>
                <div class="mb-3">
                    <input type="password" name="confirm_password" class="form-control form-control-sm" placeholder="<?= Lang::t('confirm_password') ?>" required>
                </div>
                <button type="submit" name="update_password" class="btn btn-dark btn-sm w-100"><?= Lang::t('update_password') ?></button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>