<?php
require_once '../core/Database.php';
require_once '../core/Lang.php';
require_once '../core/Auth.php';

Lang::init();
$db = (new Database())->getConnection();
$auth = new Auth($db);
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($auth->login($username, $password)) {
        header("Location: dashboard.php");
        exit;
    } else {
        $error = Lang::t('login_error');
    }
}
?>
<!DOCTYPE html>
<html lang="<?= Lang::$current ?>">
<head>
    <meta charset="UTF-8">
    <title><?= Lang::t('login_btn') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background: #f4f7f6; height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { width: 400px; border-radius: 15px; border: none; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
<div class="card login-card p-4">
    <div class="text-center mb-4">
        <h3 class="fw-bold text-primary">HISOBOT.UZ</h3>
        <div class="btn-group mt-2">
            <a href="?lang=uz" class="btn btn-sm <?= Lang::$current == 'uz' ? 'btn-dark' : 'btn-outline-dark' ?>">UZ</a>
            <a href="?lang=ru" class="btn btn-sm <?= Lang::$current == 'ru' ? 'btn-dark' : 'btn-outline-dark' ?>">RU</a>
        </div>
    </div>
    <?php if($error): ?><div class="alert alert-danger p-2 small text-center"><?= $error ?></div><?php endif; ?>
    <form method="POST">
        <div class="mb-3">
            <label class="small fw-bold"><?= Lang::t('username') ?></label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="small fw-bold"><?= Lang::t('password') ?></label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100 rounded-pill py-2 fw-bold"><?= Lang::t('login_btn') ?></button>
    </form>
</div>
</body>
</html>