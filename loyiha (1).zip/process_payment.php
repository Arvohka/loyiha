<?php
require_once 'core/Database.php';
require_once 'core/Auth.php';

Auth::check();
$db = (new Database())->getConnection();
$user_id = $_SESSION['user_id'];

// 1. Yangi to'lov yaratish
if (isset($_GET['tariff']) && isset($_GET['method'])) {
    $tariff_id = $_GET['tariff'];
    $method = $_GET['method'];

    // Tarif ma'lumotlarini olish
    $stmt = $db->prepare("SELECT * FROM tariff_plans WHERE id = ?");
    $stmt->execute([$tariff_id]);
    $tariff = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tariff) {
        header("Location: billing.php?error=not_found"); exit;
    }

    // Obuna muddati hisoblash
    $start_date = date('Y-m-d H:i:s');
    $duration = $tariff['duration_months'];
    $end_date = date('Y-m-d H:i:s', strtotime("+$duration months"));

    // Bazaga vaqtinchalik (pending) saqlash
    $ins = $db->prepare("INSERT INTO user_subscriptions (user_id, tariff_id, start_date, end_date, payment_status) VALUES (?, ?, ?, ?, 'pending')");
    $ins->execute([$user_id, $tariff_id, $start_date, $end_date]);
    $subscription_id = $db->lastInsertId();

    // To'lov tizimiga yo'naltirish (Logika)
    if ($method == 'click') {
        // Click.uz redirect URL (Namuna)
        $service_id = "YOUR_CLICK_SERVICE_ID";
        $merchant_id = "YOUR_CLICK_MERCHANT_ID";
        $amount = $tariff['price'];
        $url = "https://my.click.uz/services/pay?service_id=$service_id&merchant_id=$merchant_id&amount=$amount&transaction_param=$subscription_id";
        header("Location: $url");
    } elseif ($method == 'payme') {
        // Payme redirect (Base64 encoding talab qilinadi)
        $merchant_id = "YOUR_PAYME_ID";
        $amount = $tariff['price'] * 100; // Tiyinlarda
        $params = "m=$merchant_id;ac.subscription_id=$subscription_id;a=$amount";
        $base64 = base64_encode($params);
        $url = "https://checkout.paycom.uz/$base64";
        header("Location: $url");
    }
    exit;
}

// 2. To'lovni qayta urinish (History bo'limidan)
if (isset($_GET['retry'])) {
    $sub_id = $_GET['retry'];
    $stmt = $db->prepare("SELECT us.*, tp.price FROM user_subscriptions us JOIN tariff_plans tp ON us.tariff_id = tp.id WHERE us.id = ? AND us.user_id = ?");
    $stmt->execute([$sub_id, $user_id]);
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($sub) {
        // Bu yerda Click/Payme tanlash oynasiga qaytarish yoki default birortasiga yuborish mumkin
        header("Location: billing.php?tab=plans");
    }
    exit;
}