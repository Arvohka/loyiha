<?php
include 'includes/header.php';

// 1. Umumiy statistika (Daromad turlari bo'yicha)
$stats_stmt = $db->prepare("SELECT payment_method, SUM(amount) as total FROM orders WHERE user_id = ? GROUP BY payment_method");
$stats_stmt->execute([$user_id]);
$payment_stats = $stats_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// 2. So'nggi 7 kunlik savdo dinamikasi
$daily_stmt = $db->prepare("SELECT DATE(created_at) as date, SUM(amount) as total FROM orders WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at)");
$daily_stmt->execute([$user_id]);
$daily_data = $daily_stmt->fetchAll(PDO::FETCH_ASSOC);

$labels = []; $values = [];
foreach($daily_data as $row) {
    $labels[] = date('d-M', strtotime($row['date']));
    $values[] = $row['total'];
}
?>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-5">
            <small class="text-muted fw-bold"><?= Lang::t('cash') ?></small>
            <h5 class="fw-bold m-0"><?= number_format($payment_stats['cash'] ?? 0, 0) ?> UZS</h5>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white border-start border-info border-5">
            <small class="text-muted fw-bold"><?= Lang::t('terminal') ?></small>
            <h5 class="fw-bold m-0"><?= number_format($payment_stats['terminal'] ?? 0, 0) ?> UZS</h5>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white border-start border-danger border-5">
            <small class="text-muted fw-bold"><?= Lang::t('debt') ?></small>
            <h5 class="fw-bold m-0"><?= number_format($payment_stats['debt'] ?? 0, 0) ?> UZS</h5>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-primary text-white">
            <small class="opacity-75 fw-bold"><?= Lang::t('total_amount') ?></small>
            <h5 class="fw-bold m-0"><?= number_format(array_sum($payment_stats), 0) ?> UZS</h5>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm p-4 bg-white rounded-4">
            <h6 class="fw-bold mb-4"><?= Lang::t('sales_analytics') ?> (7 <?= Lang::t('days') ?>)</h6>
            <canvas id="salesChart" height="120"></canvas>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-4 bg-white rounded-4 h-100">
            <h6 class="fw-bold mb-4"><?= Lang::t('top_products') ?></h6>
            <div class="list-group list-group-flush">
                <?php
                $top_stmt = $db->prepare("SELECT product_name, SUM(quantity) as qty FROM order_items WHERE user_id = ? GROUP BY product_name ORDER BY qty DESC LIMIT 5");
                $top_stmt->execute([$user_id]);
                foreach($top_stmt->fetchAll() as $top): ?>
                <div class="list-group-item border-0 d-flex justify-content-between align-items-center px-0">
                    <span class="small"><?= htmlspecialchars($top['product_name']) ?></span>
                    <span class="badge bg-light text-primary border"><?= $top['qty'] ?> ta</span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>



<script>
const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: '<?= Lang::t('amount') ?>',
            data: <?= json_encode($values) ?>,
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.1)',
            fill: true,
            tension: 0.4,
            borderWidth: 3
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>

<?php include 'includes/footer.php'; ?>