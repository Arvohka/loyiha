<?php
require_once 'core/Database.php';

try {
    $db = (new Database())->getConnection();
    
    // Yangi parol: 12345
    $username = 'admin';
    $password = '12345';
    
    // Parolni xavfsiz hash qilish
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Avval foydalanuvchi borligini tekshirish
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Bor bo'lsa parolini yangilaymiz
        $update = $db->prepare("UPDATE users SET password = ?, fullname = ? WHERE username = ?");
        $update->execute([$hashed_password, 'Administrator', $username]);
        echo "✅ Admin paroli muvaffaqiyatli yangilandi: 12345";
    } else {
        // Yo'q bo'lsa yangi admin yaratamiz
        $insert = $db->prepare("INSERT INTO users (fullname, username, password, role) VALUES (?, ?, ?, ?)");
        $insert->execute(['Administrator', $username, $hashed_password, 'admin']);
        echo "✅ Yangi admin foydalanuvchisi yaratildi! Login: admin, Parol: 12345";
    }
    
    echo "<br><br><a href='admin/login.php'>Login sahifasiga o'tish</a>";

} catch (PDOException $e) {
    die("❌ Xatolik yuz berdi: " . $e->getMessage());
}