<?php
include 'includes/header.php';

// 1. Obuna va to'lov usullari limitini tekshirish
$sub_stmt = $db->prepare("SELECT tp.* FROM user_subscriptions us 
                          JOIN tariff_plans tp ON us.tariff_id = tp.id 
                          WHERE us.user_id = ? AND us.payment_status = 'paid' 
                          AND us.end_date > NOW() LIMIT 1");
$sub_stmt->execute([$user_id]);
$my_plan = $sub_stmt->fetch(PDO::FETCH_ASSOC);

if (!$my_plan) {
    echo "<div class='alert alert-danger'>".Lang::t('no_active_subscription_access')."</div>";
    include 'includes/footer.php'; exit;
}

// 2. Savdoni amalga oshirish (Post so'rovi)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['complete_sale'])) {
    $p_type = $_POST['payment_type'];
    $can_pay = false;

    if ($p_type == 'cash' && $my_plan['has_cash']) $can_pay = true;
    if ($p_type == 'terminal' && $my_plan['has_terminal']) $can_pay = true;
    if ($p_type == 'debt' && $my_plan['has_debt_book']) $can_pay = true;

    if ($can_pay) {
        // Savdo logikasi (Soddalashtirilgan)
        // Bu yerda orders va order_items jadvallariga yoziladi
        echo "<script>alert('".Lang::t('sale_completed')."'); location.href='pos.php';</script>";
    } else {
        echo "<script>alert('".Lang::t('not_allowed_method')."');</script>";
    }
}

$products = $db->prepare("SELECT * FROM inventory WHERE user_id = ? AND stock_quantity > 0");
$products->execute([$user_id]);
?>

<div class="row">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm p-3 mb-4">
            <input type="text" id="searchProduct" class="form-control" placeholder="<?= Lang::t('search') ?>...">
        </div>
        <div class="row g-3">
            <?php foreach($products->fetchAll() as $p): ?>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm product-card" onclick="addToCart(<?= $p['id'] ?>, '<?= $p['product_name'] ?>', <?= $p['price'] ?>)">
                    <div class="card-body text-center">
                        <h6 class="fw-bold"><?= htmlspecialchars($p['product_name']) ?></h6>
                        <p class="text-primary mb-0"><?= number_format($p['price'], 0) ?> UZS</p>
                        <small class="text-muted"><?= Lang::t('stock') ?>: <?= $p['stock_quantity'] ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-0 shadow-sm h-100" style="position: sticky; top: 20px;">
            <div class="card-header bg-white fw-bold"><?= Lang::t('cart') ?></div>
            <div class="card-body">
                <div id="cartItems" class="mb-4" style="min-height: 200px;">
                    </div>
                <hr>
                <div class="d-flex justify-content-between mb-3">
                    <h5 class="fw-bold"><?= Lang::t('total_amount') ?>:</h5>
                    <h5 class="fw-bold text-success" id="totalPrice">0 UZS</h5>
                </div>
                
                <form method="POST">
                    <label class="small fw-bold"><?= Lang::t('payment_type') ?></label>
                    <select name="payment_type" class="form-select mb-3" required>
                        <?php if($my_plan['has_cash']): ?><option value="cash"><?= Lang::t('cash') ?></option><?php endif; ?>
                        <?php if($my_plan['has_terminal']): ?><option value="terminal"><?= Lang::t('terminal') ?></option><?php endif; ?>
                        <?php if($my_plan['has_debt_book']): ?><option value="debt"><?= Lang::t('debt') ?></option><?php endif; ?>
                    </select>
                    <button type="submit" name="complete_sale" class="btn btn-success w-100 py-3 fw-bold rounded-pill">
                        <?= Lang::t('complete_sale') ?>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
let cart = [];
function addToCart(id, name, price) {
    cart.push({id, name, price});
    renderCart();
}

function renderCart() {
    let html = '';
    let total = 0;
    cart.forEach(item => {
        html += `<div class="d-flex justify-content-between border-bottom py-2 small">
                    <span>${item.name}</span>
                    <b>${item.price.toLocaleString()}</b>
                 </div>`;
        total += item.price;
    });
    document.getElementById('cartItems').innerHTML = html;
    document.getElementById('totalPrice').innerText = total.toLocaleString() + ' UZS';
}
</script>

<?php include 'includes/footer.php'; ?>