<?php
require_once 'core/Database.php';
session_start();

if ($_GET['type'] == 'excel') {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=hisobot.xls");
    
    $database = new Database();
    $db = $database->getConnection();
    
    $stmt = $db->prepare("SELECT title, amount, type, report_date FROM reports WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo "Nomi\tSumma\tTuri\tSana\n";
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "{$row['title']}\t{$row['amount']}\t{$row['type']}\t{$row['report_date']}\n";
    }
}
?>