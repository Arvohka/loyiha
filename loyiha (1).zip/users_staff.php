<?php
require_once 'core/Database.php';
require_once 'core/Lang.php';
require_once 'core/Auth.php';

Auth::check();
$db = (new Database())->getConnection();
$user_id = $_SESSION['user_id'];

if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'owner') {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$message = '';

// 1. Obuna limitini aniqlash (Hozirgi tarifingiz: Ishonch - 1 ta kassir)
// Bu qismni billing tizimingizga qarab moslashtirish mumkin
$max_cashiers = 1; 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_staff'])) {
    $staff_role = $_POST['staff_role'];
    $can_add = true;

    // 2. Kassir limiti tekshiruvi
    if ($staff_role === 'cashier') {
        $check = $db->prepare("SELECT COUNT(*) FROM staff WHERE owner_id = ? AND role = 'cashier'");
        $check->execute([$user_id]);
        $current_cashiers = $check->fetchColumn();

        if ($current_cashiers >= $max_cashiers) {
            $message = "<div class='alert alert-warning py-2 small'>" . Lang::t('limit_reached') . " ($max_cashiers)</div>";
            $can_add = false;
        }
    }

    // 3. Agar limitdan oshmagan bo'lsa saqlash
    if ($can_add) {
        $fullname = trim($_POST['fullname']);
        $username = trim($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        try {
            $stmt = $db->prepare("INSERT INTO staff (owner_id, fullname, username, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $fullname, $username, $password, $staff_role]);
            $message = "<div class='alert alert-success py-2 small'>" . Lang::t('staff_added') . "</div>";
        } catch (PDOException $e) {
            $message = "<div class='alert alert-danger py-2 small'>" . Lang::t('login_taken') . "</div>";
        }
    }
}

if (isset($_GET['delete_id'])) {
    $del = $db->prepare("DELETE FROM staff WHERE id = ? AND owner_id = ?");
    $del->execute([$_GET['delete_id'], $user_id]);
    header("Location: users_staff.php");
    exit;
}

include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h3 class="fw-bold"><i class="fas fa-users-cog me-2"></i> <?= Lang::t('staff_management') ?></h3>
            <p class="text-muted small"><?= Lang::t('staff_desc') ?></p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card border-0 shadow-sm p-4 rounded-4">
                <h5 class="fw-bold mb-3 small text-uppercase text-primary"><?= Lang::t('new_staff') ?></h5>
                <?= $message ?>
                <form method="POST">
                    <div class="mb-3">
                        <label class="small fw-bold"><?= Lang::t('fullname') ?></label>
                        <input type="text" name="fullname" class="form-control" placeholder="<?= Lang::t('fullname_placeholder') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold"><?= Lang::t('username') ?></label>
                        <input type="text" name="username" class="form-control" placeholder="<?= Lang::t('username_placeholder') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="small fw-bold"><?= Lang::t('password') ?></label>
                        <input type="password" name="password" class="form-control" placeholder="<?= Lang::t('password_placeholder') ?>" required>
                    </div>
                    <div class="mb-4">
                        <label class="small fw-bold"><?= Lang::t('role') ?></label>
                        <select name="staff_role" class="form-select" required>
                            <option value="cashier"><?= Lang::t('cashier') ?></option>
                            <option value="warehouseman"><?= Lang::t('warehouseman') ?></option>
                        </select>
                    </div>
                    <button type="submit" name="add_staff" class="btn btn-primary w-100 rounded-pill fw-bold py-2">
                        <i class="fas fa-save me-1"></i> <?= Lang::t('save') ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="fw-bold m-0 small text-uppercase"><i class="fas fa-list me-2 text-primary"></i> <?= Lang::t('existing_staff') ?></h5>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle m-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4"><?= Lang::t('fullname') ?></th>
                                <th><?= Lang::t('username') ?></th>
                                <th><?= Lang::t('role') ?></th>
                                <th class="pe-4 text-end"><?= Lang::t('actions') ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $list = $db->prepare("SELECT * FROM staff WHERE owner_id = ? ORDER BY created_at DESC");
                            $list->execute([$user_id]);
                            $staffs = $list->fetchAll();
                            foreach ($staffs as $s): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold"><?= htmlspecialchars($s['fullname']) ?></div>
                                    <small class="text-muted" style="font-size: 10px;"><?= $s['created_at'] ?></small>
                                </td>
                                <td><span class="badge bg-light text-dark border fw-normal"><?= htmlspecialchars($s['username']) ?></span></td>
                                <td>
                                    <span class="badge <?= $s['role']=='cashier' ? 'bg-success' : 'bg-info' ?> text-white fw-normal">
                                        <?= Lang::t($s['role']) ?>
                                    </span>
                                </td>
                                <td class="pe-4 text-end">
                                    <a href="?delete_id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('<?= Lang::t('delete_confirm') ?>')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>