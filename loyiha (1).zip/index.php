<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'core/Database.php';
require_once 'core/Lang.php';

try {
    $db = (new Database())->getConnection();
    $news = [];
    $table_check = $db->query("SHOW TABLES LIKE 'news'")->rowCount();
    if($table_check > 0) {
        $news = $db->query("SELECT * FROM news ORDER BY created_at DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="<?= Lang::$current ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hisobot.uz - Professional Tizim</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero { background: linear-gradient(45deg, #4e73df, #224abe); color: white; padding: 100px 0; }
        .card-news { transition: 0.3s; border: none; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .card-news:hover { transform: translateY(-5px); }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="#">HISOBOT.UZ</a>
            <div class="ms-auto d-flex align-items-center">
                <a href="?lang=uz" class="nav-link px-2 <?= Lang::$current == 'uz' ? 'fw-bold text-primary' : '' ?>">UZ</a>
                <span class="text-muted">|</span>
                <a href="?lang=ru" class="nav-link px-2 <?= Lang::$current == 'ru' ? 'fw-bold text-primary' : '' ?>">RU</a>
                <a href="login.php" class="btn btn-primary ms-3 rounded-pill px-4"><?= Lang::t('login_btn') ?></a>
            </div>
        </div>
    </nav>

    <header class="hero text-center">
        <div class="container">
            <h1 class="display-4 fw-bold mb-4"><?= Lang::t('hero_title') ?></h1>
            <p class="lead mb-5"><?= Lang::t('hero_desc') ?></p>
            <a href="login.php" class="btn btn-light btn-lg px-5 rounded-pill shadow"><?= Lang::t('login_btn') ?></a>
        </div>
    </header>

    <section class="container my-5 py-5">
        <h2 class="text-center fw-bold mb-5"><?= Lang::t('features') ?></h2>
        <div class="row g-4 text-center">
            <div class="col-md-4">
                <div class="p-4 bg-light rounded-4">
                    <h3><?= Lang::t('feature_1') ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 bg-light rounded-4">
                    <h3><?= Lang::t('feature_2') ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 bg-light rounded-4">
                    <h3><?= Lang::t('feature_3') ?></h3>
                </div>
            </div>
        </div>
    </section>

    <?php if(!empty($news)): ?>
    <section class="bg-light py-5">
        <div class="container">
            <h2 class="text-center fw-bold mb-5"><?= Lang::t('news') ?></h2>
            <div class="row g-4">
                <?php foreach($news as $item): ?>
                <div class="col-md-4">
                    <div class="card h-100 card-news">
                        <div class="card-body">
                            <h5 class="fw-bold"><?= Lang::db($item, 'title') ?></h5>
                            <p class="text-muted small"><?= Lang::db($item, 'content') ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <footer class="bg-dark text-white py-4 mt-5 text-center">
        <p class="mb-0 opacity-50">&copy; 2026 Hisobot.uz. Barcha huquqlar himoyalangan.</p>
    </footer>
</body>
</html>