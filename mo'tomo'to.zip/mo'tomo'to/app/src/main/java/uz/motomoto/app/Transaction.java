package uz.motomoto.app;

final class Transaction {
    final long id;
    final String type;
    final double amount;
    final String note;
    final long createdAt;

    Transaction(long id, String type, double amount, String note, long createdAt) {
        this.id = id;
        this.type = type;
        this.amount = amount;
        this.note = note;
        this.createdAt = createdAt;
    }
}
