package uz.motomoto.app;

final class Reminder {
    final long id;
    final String text;
    final long remindAt;

    Reminder(long id, String text, long remindAt) {
        this.id = id;
        this.text = text;
        this.remindAt = remindAt;
    }
}
