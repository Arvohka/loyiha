package uz.motomoto.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

final class MotomotoDatabase extends SQLiteOpenHelper {
    private static final String NAME = "motomoto.db";
    private static final int VERSION = 1;

    MotomotoDatabase(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE transactions_table (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "type TEXT NOT NULL," +
                "amount REAL NOT NULL," +
                "note TEXT," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE reminders (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "text TEXT NOT NULL," +
                "remind_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS transactions_table");
        db.execSQL("DROP TABLE IF EXISTS reminders");
        onCreate(db);
    }

    long addTransaction(String type, double amount, String note) {
        ContentValues values = new ContentValues();
        values.put("type", type);
        values.put("amount", amount);
        values.put("note", note);
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("transactions_table", null, values);
    }

    long addReminder(String text, long remindAt) {
        ContentValues values = new ContentValues();
        values.put("text", text);
        values.put("remind_at", remindAt);
        return getWritableDatabase().insert("reminders", null, values);
    }

    List<Transaction> getRecentTransactions() {
        List<Transaction> items = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(
                "transactions_table",
                null,
                null,
                null,
                null,
                null,
                "created_at DESC",
                "25");
        try {
            while (cursor.moveToNext()) {
                items.add(new Transaction(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("type")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                        cursor.getString(cursor.getColumnIndexOrThrow("note")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("created_at"))));
            }
        } finally {
            cursor.close();
        }
        return items;
    }

    List<Reminder> getUpcomingReminders() {
        List<Reminder> items = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(
                "reminders",
                null,
                null,
                null,
                null,
                null,
                "remind_at ASC",
                "25");
        try {
            while (cursor.moveToNext()) {
                items.add(new Reminder(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("text")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("remind_at"))));
            }
        } finally {
            cursor.close();
        }
        return items;
    }

    double sumByType(String type) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(amount), 0) FROM transactions_table WHERE type = ?",
                new String[]{type});
        try {
            return cursor.moveToFirst() ? cursor.getDouble(0) : 0;
        } finally {
            cursor.close();
        }
    }
}
