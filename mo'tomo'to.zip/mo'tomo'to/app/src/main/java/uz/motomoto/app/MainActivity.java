package uz.motomoto.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final int REQ_REMINDER_SPEECH = 120;
    private static final int REQ_RECORD_AUDIO = 121;
    private static final int REQ_NOTIFICATIONS = 122;
    private static final int REQ_TRANSACTION_SPEECH = 123;
    private static final int VOICE_MODE_NONE = 0;
    private static final int VOICE_MODE_TRANSACTION = 1;
    private static final int VOICE_MODE_REMINDER = 2;
    private static final Pattern DIGIT_PATTERN = Pattern.compile("\\d[\\d\\s.,]*");

    private final NumberFormat moneyFormat = NumberFormat.getNumberInstance(Locale.US);
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US);
    private final Map<String, Long> numberWords = buildNumberWords();

    private MotomotoDatabase database;
    private TextView incomeText;
    private TextView expenseText;
    private TextView balanceText;
    private TextView transactionsList;
    private TextView remindersList;
    private EditText amountInput;
    private EditText noteInput;
    private EditText reminderInput;
    private EditText reminderMinutesInput;
    private RadioGroup languageGroup;
    private RadioGroup typeGroup;
    private int uzbekRadioId;
    private int russianRadioId;
    private int incomeRadioId;
    private int expenseRadioId;
    private int pendingVoiceMode = VOICE_MODE_NONE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = new MotomotoDatabase(this);
        ReminderReceiver.ensureChannel(this);
        requestNotificationPermissionIfNeeded();
        setContentView(buildContent());
        refreshDashboard();
    }

    private View buildContent() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.rgb(247, 248, 243));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(26));
        scrollView.addView(root);

        TextView title = text("Mo'tomo'to", 30, true);
        title.setTextColor(Color.rgb(24, 32, 28));
        root.addView(title);

        TextView subtitle = text("Kunlik pul oqimi va eslatmalar bir joyda.", 15, false);
        subtitle.setTextColor(Color.rgb(78, 88, 82));
        subtitle.setPadding(0, dp(4), 0, dp(16));
        root.addView(subtitle);

        root.addView(sectionTitle("Til / Язык"));
        languageGroup = new RadioGroup(this);
        languageGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton uzbek = new RadioButton(this);
        uzbek.setText("O'zbek");
        uzbek.setId(View.generateViewId());
        uzbekRadioId = uzbek.getId();
        uzbek.setChecked(true);
        RadioButton russian = new RadioButton(this);
        russian.setText("Русский");
        russian.setId(View.generateViewId());
        russianRadioId = russian.getId();
        languageGroup.addView(uzbek);
        languageGroup.addView(russian);
        languageGroup.setOnCheckedChangeListener((group, checkedId) -> refreshDashboard());
        root.addView(languageGroup);

        LinearLayout summary = panel();
        incomeText = text("", 16, true);
        expenseText = text("", 16, true);
        balanceText = text("", 22, true);
        summary.addView(incomeText);
        summary.addView(expenseText);
        summary.addView(balanceText);
        root.addView(summary);

        root.addView(sectionTitle("Kirim/chiqim qo'shish / Доход/расход"));
        typeGroup = new RadioGroup(this);
        typeGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton income = new RadioButton(this);
        income.setText("Kirim / Доход");
        income.setId(View.generateViewId());
        incomeRadioId = income.getId();
        income.setChecked(true);
        RadioButton expense = new RadioButton(this);
        expense.setText("Chiqim / Расход");
        expense.setId(View.generateViewId());
        expenseRadioId = expense.getId();
        typeGroup.addView(income);
        typeGroup.addView(expense);
        root.addView(typeGroup);

        Button voiceTransaction = primaryButton("Gapirib qo'shish / Сказать");
        voiceTransaction.setOnClickListener(v -> startTransactionVoiceInput());
        root.addView(voiceTransaction);

        amountInput = input("Miqdor / Сумма, masalan 50000");
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(amountInput);

        noteInput = input("Izoh / Комментарий, masalan tushlik yoki обед");
        root.addView(noteInput);

        Button addTransaction = secondaryButton("Qo'lda saqlash / Сохранить вручную");
        addTransaction.setOnClickListener(v -> saveTransaction());
        root.addView(addTransaction);

        root.addView(sectionTitle("Oxirgi amallar / Последние операции"));
        transactionsList = text("", 15, false);
        transactionsList.setLineSpacing(0, 1.12f);
        root.addView(transactionsList);

        root.addView(sectionTitle("Eslatma qo'shish / Напоминание"));
        reminderInput = input("Eslatma matni / Текст напоминания");
        reminderInput.setMinLines(2);
        root.addView(reminderInput);

        Button voiceButton = primaryButton("Eslatmani gapirish / Сказать");
        voiceButton.setOnClickListener(v -> startReminderVoiceInput());
        root.addView(voiceButton);

        reminderMinutesInput = input("Necha daqiqadan keyin? / Через сколько минут?");
        reminderMinutesInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        root.addView(reminderMinutesInput);

        Button addReminder = primaryButton("Eslatmani saqlash / Сохранить");
        addReminder.setOnClickListener(v -> saveReminder());
        root.addView(addReminder);

        root.addView(sectionTitle("Eslatmalar / Напоминания"));
        remindersList = text("", 15, false);
        remindersList.setLineSpacing(0, 1.12f);
        root.addView(remindersList);

        return scrollView;
    }

    private void saveTransaction() {
        String amountRaw = amountInput.getText().toString().trim();
        if (amountRaw.isEmpty()) {
            toast("Miqdorni kiriting");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountRaw);
        } catch (NumberFormatException error) {
            toast("Miqdor noto'g'ri kiritildi");
            return;
        }

        if (amount <= 0) {
            toast("Miqdor 0 dan katta bo'lishi kerak");
            return;
        }

        saveTransactionValues(typeGroup.getCheckedRadioButtonId() == incomeRadioId ? "income" : "expense",
                amount,
                noteInput.getText().toString().trim());
    }

    private void saveTransactionValues(String type, double amount, String note) {
        database.addTransaction(type, amount, note);
        amountInput.setText("");
        noteInput.setText("");
        refreshDashboard();
        toast("Saqlandi");
    }

    private void startTransactionVoiceInput() {
        pendingVoiceMode = VOICE_MODE_TRANSACTION;
        startSpeech(REQ_TRANSACTION_SPEECH,
                isRussian() ? "Например: расход 45000 обед" : "Masalan: chiqim 45000 tushlik");
    }

    private void startReminderVoiceInput() {
        pendingVoiceMode = VOICE_MODE_REMINDER;
        startSpeech(REQ_REMINDER_SPEECH,
                isRussian() ? "Например: через 20 минут оплатить аренду" : "Masalan: 20 daqiqadan keyin ijara pulini eslat");
    }

    private void startSpeech(int requestCode, String prompt) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, isRussian() ? "ru-RU" : "uz-UZ");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, prompt);

        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception error) {
            toast("Bu qurilmada ovozdan matnga olish topilmadi");
        }
    }

    private void saveReminder() {
        String text = reminderInput.getText().toString().trim();
        String minutesRaw = reminderMinutesInput.getText().toString().trim();
        if (text.isEmpty()) {
            toast("Eslatma matnini kiriting");
            return;
        }
        if (minutesRaw.isEmpty()) {
            toast("Daqiqani kiriting");
            return;
        }

        long minutes;
        try {
            minutes = Long.parseLong(minutesRaw);
        } catch (NumberFormatException error) {
            toast("Daqiqa noto'g'ri kiritildi");
            return;
        }

        if (minutes <= 0) {
            toast("Daqiqa 0 dan katta bo'lishi kerak");
            return;
        }

        long remindAt = System.currentTimeMillis() + minutes * 60_000L;
        long id = database.addReminder(text, remindAt);
        scheduleReminder(id, text, remindAt);

        reminderInput.setText("");
        reminderMinutesInput.setText("");
        refreshDashboard();
        toast("Eslatma saqlandi");
    }

    private void scheduleReminder(long id, String text, long remindAt) {
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra(ReminderReceiver.EXTRA_TEXT, text);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                (int) id,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, remindAt, pendingIntent);
        }
    }

    private void refreshDashboard() {
        double income = database.sumByType("income");
        double expense = database.sumByType("expense");
        double balance = income - expense;

        incomeText.setText((isRussian() ? "Доход: " : "Kirim: ") + formatMoney(income));
        incomeText.setTextColor(Color.rgb(20, 107, 77));
        expenseText.setText((isRussian() ? "Расход: " : "Chiqim: ") + formatMoney(expense));
        expenseText.setTextColor(Color.rgb(179, 58, 58));
        balanceText.setText((isRussian() ? "Баланс: " : "Balans: ") + formatMoney(balance));
        balanceText.setTextColor(Color.rgb(24, 32, 28));

        List<String> transactions = new ArrayList<>();
        for (Transaction item : database.getRecentTransactions()) {
            String sign = item.type.equals("income") ? "+" : "-";
            String note = item.note == null || item.note.trim().isEmpty() ? (isRussian() ? "Без комментария" : "Izohsiz") : item.note;
            transactions.add(sign + formatMoney(item.amount) + "  " + note + "\n" + dateFormat.format(new Date(item.createdAt)));
        }
        transactionsList.setText(transactions.isEmpty() ? (isRussian() ? "Операций пока нет." : "Hali amal yo'q.") : joinLines(transactions));

        List<String> reminders = new ArrayList<>();
        for (Reminder item : database.getUpcomingReminders()) {
            reminders.add(item.text + "\n" + dateFormat.format(new Date(item.remindAt)));
        }
        remindersList.setText(reminders.isEmpty() ? (isRussian() ? "Напоминаний пока нет." : "Hali eslatma yo'q.") : joinLines(reminders));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQ_TRANSACTION_SPEECH || requestCode == REQ_REMINDER_SPEECH) &&
                resultCode == RESULT_OK &&
                data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                if (requestCode == REQ_TRANSACTION_SPEECH) {
                    handleTransactionSpeech(results.get(0));
                } else {
                    handleReminderSpeech(results.get(0));
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO &&
                grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingVoiceMode == VOICE_MODE_TRANSACTION) {
                startTransactionVoiceInput();
            } else if (pendingVoiceMode == VOICE_MODE_REMINDER) {
                startReminderVoiceInput();
            }
        }
    }

    private void handleTransactionSpeech(String speech) {
        String normalized = normalizeSpeech(speech);
        String type = isIncomeSpeech(normalized) ? "income" : "expense";
        Double amount = extractNumber(normalized);
        if (amount == null || amount <= 0) {
            toast(isRussian() ? "Не понял сумму. Например: расход 45000 обед" : "Miqdorni tushunmadim. Masalan: chiqim 45000 tushlik");
            return;
        }

        String note = cleanupTransactionNote(normalized);
        if (note.isEmpty()) {
            note = speech;
        }

        typeGroup.check(type.equals("income") ? incomeRadioId : expenseRadioId);
        amountInput.setText(String.valueOf(amount.longValue()));
        noteInput.setText(note);
        saveTransactionValues(type, amount, note);
    }

    private void handleReminderSpeech(String speech) {
        String normalized = normalizeSpeech(speech);
        Double minutes = extractNumber(normalized);
        String text = cleanupReminderText(normalized);

        if (minutes != null && minutes > 0) {
            reminderMinutesInput.setText(String.valueOf(minutes.longValue()));
        }
        reminderInput.setText(text.isEmpty() ? speech : text);
        reminderInput.setSelection(reminderInput.length());

        if (minutes != null && minutes > 0 && !reminderInput.getText().toString().trim().isEmpty()) {
            saveReminder();
        } else {
            toast(isRussian() ? "Скажите время. Например: через 20 минут выпить лекарство" : "Vaqtni ham ayting. Masalan: 20 daqiqadan keyin dorini ichish");
        }
    }

    private boolean isIncomeSpeech(String speech) {
        return speech.contains("kirim") ||
                speech.contains("daromad") ||
                speech.contains("доход") ||
                speech.contains("приход") ||
                speech.contains("зачисление") ||
                speech.contains("зарплата");
    }

    private String cleanupTransactionNote(String speech) {
        return removeNumberWords(speech)
                .replace("kirim", "")
                .replace("chiqim", "")
                .replace("daromad", "")
                .replace("xarajat", "")
                .replace("доход", "")
                .replace("приход", "")
                .replace("зачисление", "")
                .replace("расход", "")
                .replace("трата", "")
                .replace("затрата", "")
                .replace("сум", "")
                .replace("руб", "")
                .replace("рублей", "")
                .replace("som", "")
                .replace("so'm", "")
                .trim();
    }

    private String cleanupReminderText(String speech) {
        return removeNumberWords(speech)
                .replace("daqiqadan keyin", "")
                .replace("minutdan keyin", "")
                .replace("minut keyin", "")
                .replace("через", "")
                .replace("минут", "")
                .replace("минуту", "")
                .replace("минуты", "")
                .replace("напомни", "")
                .replace("напомнить", "")
                .replace("keyin", "")
                .replace("eslat", "")
                .trim();
    }

    private String removeNumberWords(String speech) {
        String result = " " + speech.replaceAll("\\d[\\d\\s.,]*", " ") + " ";
        for (String word : numberWords.keySet()) {
            result = result.replace(" " + word + " ", " ");
        }
        return result.replace(" yuz ", " ")
                .replace(" ming ", " ")
                .replace(" million ", " ")
                .replace(" milliard ", " ")
                .replace(" сто ", " ")
                .replace(" тысяча ", " ")
                .replace(" тысячи ", " ")
                .replace(" тысяч ", " ")
                .replace(" миллион ", " ")
                .replace(" миллиона ", " ")
                .replace(" миллионов ", " ")
                .replace(" миллиард ", " ")
                .replace(" миллиарда ", " ")
                .replace(" миллиардов ", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private Double extractNumber(String speech) {
        Matcher matcher = DIGIT_PATTERN.matcher(speech);
        if (matcher.find()) {
            String digits = matcher.group().replaceAll("[^0-9]", "");
            if (!digits.isEmpty()) {
                return Double.parseDouble(digits);
            }
        }

        long words = parseNumberWords(speech);
        return words > 0 ? (double) words : null;
    }

    private long parseNumberWords(String speech) {
        long total = 0;
        long current = 0;
        for (String raw : speech.split("\\s+")) {
            String word = raw.trim();
            if (numberWords.containsKey(word)) {
                current += numberWords.get(word);
            } else if (word.equals("yuz")) {
                current = current == 0 ? 100 : current * 100;
            } else if (word.equals("сто") || word.equals("сот")) {
                current = current == 0 ? 100 : current * 100;
            } else if (word.equals("ming") || word.equals("тысяча") || word.equals("тысячи") || word.equals("тысяч")) {
                total += (current == 0 ? 1 : current) * 1000;
                current = 0;
            } else if (word.equals("million") || word.equals("mln") || word.equals("миллион") || word.equals("миллиона") || word.equals("миллионов")) {
                total += (current == 0 ? 1 : current) * 1_000_000;
                current = 0;
            } else if (total > 0 || current > 0) {
                break;
            }
        }
        return total + current;
    }

    private String normalizeSpeech(String speech) {
        return speech.toLowerCase(Locale.ROOT)
                .replace("ў", "o'")
                .replace("ғ", "g'")
                .replace("қ", "q")
                .replace("ҳ", "h")
                .replace("ʼ", "'")
                .replace("`", "'")
                .replaceAll("[^\\p{L}0-9'\\s.,]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private Map<String, Long> buildNumberWords() {
        Map<String, Long> words = new HashMap<>();
        words.put("nol", 0L);
        words.put("bir", 1L);
        words.put("ikki", 2L);
        words.put("uch", 3L);
        words.put("tort", 4L);
        words.put("to'rt", 4L);
        words.put("besh", 5L);
        words.put("olti", 6L);
        words.put("yetti", 7L);
        words.put("sakkiz", 8L);
        words.put("toqiz", 9L);
        words.put("to'qiz", 9L);
        words.put("to'qqiz", 9L);
        words.put("on", 10L);
        words.put("o'n", 10L);
        words.put("yigirma", 20L);
        words.put("ottiz", 30L);
        words.put("o'ttiz", 30L);
        words.put("qirq", 40L);
        words.put("ellik", 50L);
        words.put("oltmish", 60L);
        words.put("yetmish", 70L);
        words.put("sakson", 80L);
        words.put("toqson", 90L);
        words.put("to'qson", 90L);
        words.put("один", 1L);
        words.put("одна", 1L);
        words.put("два", 2L);
        words.put("две", 2L);
        words.put("три", 3L);
        words.put("четыре", 4L);
        words.put("пять", 5L);
        words.put("шесть", 6L);
        words.put("семь", 7L);
        words.put("восемь", 8L);
        words.put("девять", 9L);
        words.put("десять", 10L);
        words.put("одиннадцать", 11L);
        words.put("двенадцать", 12L);
        words.put("тринадцать", 13L);
        words.put("четырнадцать", 14L);
        words.put("пятнадцать", 15L);
        words.put("шестнадцать", 16L);
        words.put("семнадцать", 17L);
        words.put("восемнадцать", 18L);
        words.put("девятнадцать", 19L);
        words.put("двадцать", 20L);
        words.put("тридцать", 30L);
        words.put("сорок", 40L);
        words.put("пятьдесят", 50L);
        words.put("шестьдесят", 60L);
        words.put("семьдесят", 70L);
        words.put("восемьдесят", 80L);
        words.put("девяносто", 90L);
        words.put("двести", 200L);
        words.put("триста", 300L);
        words.put("четыреста", 400L);
        words.put("пятьсот", 500L);
        words.put("шестьсот", 600L);
        words.put("семьсот", 700L);
        words.put("восемьсот", 800L);
        words.put("девятьсот", 900L);
        return words;
    }

    private boolean isRussian() {
        return languageGroup != null && languageGroup.getCheckedRadioButtonId() == russianRadioId;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private LinearLayout panel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        panel.setBackgroundColor(Color.WHITE);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        return panel;
    }

    private TextView sectionTitle(String value) {
        TextView view = text(value, 19, true);
        view.setTextColor(Color.rgb(24, 32, 28));
        view.setPadding(0, dp(22), 0, dp(8));
        return view;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(Color.rgb(45, 54, 49));
        if (bold) {
            view.setTypeface(null, android.graphics.Typeface.BOLD);
        }
        return view;
    }

    private EditText input(String hint) {
        EditText editText = new EditText(this);
        editText.setHint(hint);
        editText.setSingleLine(false);
        editText.setPadding(dp(10), dp(8), dp(10), dp(8));
        editText.setTextSize(16);
        editText.setLayoutParams(spacedParams());
        return editText;
    }

    private Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(Color.rgb(20, 107, 77));
        button.setLayoutParams(spacedParams());
        return button;
    }

    private Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextColor(Color.rgb(20, 107, 77));
        button.setLayoutParams(spacedParams());
        return button;
    }

    private LinearLayout.LayoutParams spacedParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dp(6), 0, dp(6));
        return params;
    }

    private String formatMoney(double amount) {
        return moneyFormat.format(amount) + (isRussian() ? " сум" : " so'm");
    }

    private String joinLines(List<String> lines) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) {
                builder.append("\n\n");
            }
            builder.append(lines.get(i));
        }
        return builder.toString();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
