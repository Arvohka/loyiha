# Mo'tomo'to

Mo'tomo'to - kundalik kirim-chiqimlarni hisoblab boradigan va ovoz orqali eslatma kiritishga yordam beradigan Android ilova. Ilova o'zbek va rus tillarida ovozli buyruqlarni tushunadi.

## Asosiy imkoniyatlar

- Kunlik kirim va chiqim qo'shish
- Kirim-chiqimni ovoz orqali aytib avtomatik saqlash
- Ovozli buyruq tilini `O'zbek` yoki `Русский` qilib tanlash
- Jami kirim, jami chiqim va balansni ko'rish
- Oxirgi amallar ro'yxatini ko'rish
- Eslatma matni va vaqtini ovoz orqali aytib avtomatik saqlash
- Belgilangan vaqtda notification chiqarish

## Ovozli buyruq namunalari

- `chiqim 45000 tushlik`
- `kirim 500000 oylik`
- `chiqim qirq besh ming yo'l kira`
- `20 daqiqadan keyin dorini ichish`
- `расход 45000 обед`
- `доход 500000 зарплата`
- `расход сорок пять тысяч такси`
- `через 20 минут оплатить аренду`

## Ishga tushirish

1. Loyihani Android Studio'da oching.
2. `local.properties` ichida Android SDK yo'li avtomatik sozlanganini tekshiring.
3. Gradle sync tugagach, ilovani emulator yoki telefon orqali ishga tushiring.

Android ruxsatlari:

- `RECORD_AUDIO` - ovozdan matn olish uchun
- `POST_NOTIFICATIONS` - Android 13+ qurilmalarda eslatma bildirishnomasi uchun
